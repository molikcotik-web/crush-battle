create table if not exists bot_users (
  id text primary key,
  telegram_id text unique,
  username text,
  first_name text,
  language text not null default 'en',
  niche text,
  is_premium boolean not null default false,
  is_admin boolean not null default false,
  generations_today integer not null default 0,
  generation_date date,
  total_generations integer not null default 0,
  last_active_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create index if not exists bot_users_telegram_id_idx on bot_users (telegram_id);
create index if not exists bot_users_last_active_idx on bot_users (last_active_at);

create table if not exists bot_sessions (
  user_id text primary key references bot_users (id) on delete cascade,
  state jsonb not null,
  updated_at timestamptz not null default now()
);

create table if not exists generations (
  id serial primary key,
  user_id text not null references bot_users (id) on delete cascade,
  platform text not null,
  niche text not null,
  language text not null,
  style text not null,
  ideas jsonb not null,
  created_at timestamptz not null default now()
);

create index if not exists generations_user_id_idx on generations (user_id);
create index if not exists generations_created_at_idx on generations (created_at);

create table if not exists saved_ideas (
  id serial primary key,
  user_id text not null references bot_users (id) on delete cascade,
  idea jsonb not null,
  created_at timestamptz not null default now()
);

create index if not exists saved_ideas_user_id_idx on saved_ideas (user_id);

create table if not exists daily_packs (
  pack_date date not null,
  language text not null,
  ideas jsonb not null,
  created_at timestamptz not null default now(),
  primary key (pack_date, language)
);

create table if not exists trending_cache (
  cache_date date not null,
  language text not null,
  ideas jsonb not null,
  created_at timestamptz not null default now(),
  primary key (cache_date, language)
);

create table if not exists broadcasts (
  id serial primary key,
  message text not null,
  sent_count integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists telegram_updates (
  update_id bigint primary key,
  received_at timestamptz not null default now()
);
