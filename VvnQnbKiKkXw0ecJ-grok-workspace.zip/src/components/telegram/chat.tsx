import { useEffect, useRef, useState, type ReactNode } from "react";
import { toast } from "sonner";
import { ensureWebSession, sendBotAction } from "@/lib/bot/fns";
import {
  formatIdeaPlain,
  PLATFORM_META,
} from "@/lib/bot/catalog";
import type { ChatMessage, PublicUser, VideoIdea } from "@/lib/bot/types";
import { cn } from "@/lib/utils";

const TOKEN_KEY = "vib.session";

function useSessionToken() {
  const [token, setToken] = useState<string | null>(null);
  useEffect(() => {
    setToken(localStorage.getItem(TOKEN_KEY));
  }, []);
  const save = (next: string) => {
    localStorage.setItem(TOKEN_KEY, next);
    setToken(next);
  };
  return { token, save };
}

export function TelegramChat({ compact = false }: { compact?: boolean }) {
  const { token, save } = useSessionToken();
  const [user, setUser] = useState<PublicUser | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [busy, setBusy] = useState(false);
  const [booting, setBooting] = useState(true);
  const scroller = useRef<HTMLDivElement>(null);
  const tokenRef = useRef<string | null>(null);

  useEffect(() => {
    tokenRef.current = token;
  }, [token]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const stored = localStorage.getItem(TOKEN_KEY) ?? undefined;
        const res = await ensureWebSession({ data: { token: stored } });
        if (cancelled) return;
        save(res.token);
        tokenRef.current = res.token;
        setUser(res.user);
        if (res.messages.length) setMessages(res.messages);
        else {
          const start = await sendBotAction({
            data: { token: res.token, action: "/start" },
          });
          if (cancelled) return;
          setUser(start.user);
          setMessages(start.messages);
        }
      } catch (err) {
        toast.error(err instanceof Error ? err.message : "Could not start the bot");
      } finally {
        if (!cancelled) setBooting(false);
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const el = scroller.current;
    if (!el) return;
    el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
  }, [messages, busy]);

  async function run(action: string, label?: string) {
    const active = tokenRef.current;
    if (!active || busy) return;
    if (label) {
      setMessages((m) => [
        ...m,
        {
          id: crypto.randomUUID(),
          role: "user",
          text: label,
          createdAt: new Date().toISOString(),
        },
      ]);
    }
    setBusy(true);
    try {
      const res = await sendBotAction({ data: { token: active, action } });
      setUser(res.user);
      setMessages((m) => [...m, ...res.messages]);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Action failed");
    } finally {
      setBusy(false);
    }
  }

  async function copyIdea(idea: VideoIdea) {
    await navigator.clipboard.writeText(formatIdeaPlain(idea));
    toast.success("Idea copied");
  }

  return (
    <div className={cn("tg-app flex h-full min-h-0 flex-col", compact && "text-sm")}>
      <header className="flex items-center gap-3 border-b border-[var(--tg-line)] bg-[var(--tg-header)] px-3 py-2.5">
        <div className="grid size-10 place-items-center rounded-full bg-[var(--tg-mine)] text-sm font-semibold tracking-tight">
          VI
        </div>
        <div className="min-w-0 flex-1">
          <p className="truncate font-medium leading-tight">Video Ideas Bot</p>
          <p className="truncate text-xs text-[var(--tg-meta)]">
            {busy ? "typing…" : "online · short-form studio"}
          </p>
        </div>
        {user ? (
          <span className="rounded-full bg-[var(--tg-btn)] px-2.5 py-1 text-[11px] tabular-nums text-[var(--tg-btn-fg)]">
            {user.isPremium ? "Premium" : `${user.remaining}/${user.dailyLimit}`}
          </span>
        ) : null}
      </header>

      <div ref={scroller} className="tg-scroll min-h-0 flex-1 space-y-3 overflow-y-auto px-3 py-4 pb-8">
        {booting ? (
          <div className="flex justify-center pt-10 text-sm text-[var(--tg-meta)]">
            Opening chat…
          </div>
        ) : null}
        {messages.map((m) => (
          <MessageBubble
            key={m.id}
            message={m}
            busy={busy}
            onAction={run}
            onCopy={copyIdea}
          />
        ))}
        {busy ? (
          <div className="flex justify-start">
            <div className="rounded-2xl rounded-bl-sm bg-[var(--tg-bubble)] px-3 py-2 text-[var(--tg-meta)]">
              <span className="inline-flex gap-1">
                <i className="inline-block size-1.5 animate-pulse rounded-full bg-[var(--tg-accent)]" />
                <i className="inline-block size-1.5 animate-pulse rounded-full bg-[var(--tg-accent)] [animation-delay:120ms]" />
                <i className="inline-block size-1.5 animate-pulse rounded-full bg-[var(--tg-accent)] [animation-delay:240ms]" />
              </span>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}

function MessageBubble({
  message,
  busy,
  onAction,
  onCopy,
}: {
  message: ChatMessage;
  busy: boolean;
  onAction: (action: string, label?: string) => void;
  onCopy: (idea: VideoIdea) => void;
}) {
  const mine = message.role === "user";
  return (
    <div className={cn("flex", mine ? "justify-end" : "justify-start")}>
      <div
        className={cn(
          "max-w-[92%] rounded-2xl px-3 py-2 leading-relaxed",
          mine
            ? "rounded-br-sm bg-[var(--tg-mine)] text-[var(--tg-bubble-fg)]"
            : "rounded-bl-sm bg-[var(--tg-bubble)] text-[var(--tg-bubble-fg)]",
        )}
      >
        {message.idea ? (
          <IdeaCard
            idea={message.idea}
            text={message.text}
            buttons={message.buttons}
            busy={busy}
            onAction={onAction}
            onCopy={onCopy}
          />
        ) : (
          <p className="whitespace-pre-wrap">{message.text}</p>
        )}
        {message.buttons && !message.idea ? (
          <ButtonGrid buttons={message.buttons} busy={busy} onAction={onAction} />
        ) : null}
      </div>
    </div>
  );
}

function IdeaCard({
  idea,
  text,
  buttons,
  busy,
  onAction,
  onCopy,
}: {
  idea: VideoIdea;
  text: string;
  buttons?: ChatMessage["buttons"];
  busy: boolean;
  onAction: (action: string, label?: string) => void;
  onCopy: (idea: VideoIdea) => void;
}) {
  const platform = PLATFORM_META[idea.platform]?.short ?? idea.platform;
  const saveBtn = buttons?.[0]?.find((b) => b.action.startsWith("save:"));
  const extra = buttons
    ?.flat()
    .filter((b) => !b.action.startsWith("save:") && !b.action.startsWith("copy:"));
  return (
    <div className="space-y-2">
      <div className="flex flex-wrap items-center gap-1.5 text-[10px] uppercase tracking-wider text-[var(--tg-meta)]">
        <span>{platform}</span>
        <span>·</span>
        <span>{idea.niche}</span>
        <span>·</span>
        <span>{idea.style}</span>
        <span>·</span>
        <span>{idea.length}</span>
      </div>
      <p className="font-medium leading-snug">{idea.title}</p>
      <Field label="Hook" value={idea.hook} />
      <Field label="Happens" value={idea.whatHappens} />
      <Field label="Script" value={idea.script} />
      <Field label="Caption" value={idea.caption} />
      <p className="text-[12px] text-[var(--tg-accent)]">{idea.hashtags.join(" ")}</p>
      <p className="text-[12px] text-[var(--tg-meta)]">CTA · {idea.cta}</p>
      <div className="flex flex-wrap gap-1.5 pt-1">
        {saveBtn ? (
          <TgButton
            disabled={busy}
            onClick={() => onAction(saveBtn.action, saveBtn.text)}
          >
            {saveBtn.text}
          </TgButton>
        ) : null}
        <TgButton disabled={busy} onClick={() => onCopy(idea)}>
          Copy
        </TgButton>
        {extra?.map((b) => (
          <TgButton
            key={b.action}
            disabled={busy}
            onClick={() => onAction(b.action, b.text)}
          >
            {b.text}
          </TgButton>
        ))}
      </div>
      <span className="sr-only">{text}</span>
    </div>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-[10px] uppercase tracking-wider text-[var(--tg-meta)]">{label}</p>
      <p className="whitespace-pre-wrap text-[13px]">{value}</p>
    </div>
  );
}

function ButtonGrid({
  buttons,
  busy,
  onAction,
}: {
  buttons: NonNullable<ChatMessage["buttons"]>;
  busy: boolean;
  onAction: (action: string, label?: string) => void;
}) {
  return (
    <div className="mt-2 space-y-1.5">
      {buttons.map((row, i) => (
        <div key={i} className="flex flex-wrap gap-1.5">
          {row.map((b) => (
            <TgButton
              key={b.action}
              disabled={busy}
              onClick={() => onAction(b.action, b.text)}
            >
              {b.text}
            </TgButton>
          ))}
        </div>
      ))}
    </div>
  );
}

function TgButton({
  children,
  onClick,
  disabled,
}: {
  children: ReactNode;
  onClick: () => void;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      className="min-h-10 flex-1 rounded-md bg-[var(--tg-btn)] px-2.5 py-2 text-left text-[13px] font-medium text-[var(--tg-btn-fg)] transition-[transform,opacity] duration-150 ease-out hover:opacity-90 active:scale-[0.96] disabled:opacity-50"
    >
      {children}
    </button>
  );
}
