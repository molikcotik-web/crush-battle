import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function PhoneFrame({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "relative mx-auto w-full max-w-[390px]",
        className,
      )}
    >
      <div className="rounded-[2rem] bg-elevated p-2 shadow-[var(--shadow-border)]">
        <div className="relative overflow-hidden rounded-[1.55rem] bg-[var(--tg-bg,#0e1621)]">
          <div className="pointer-events-none absolute inset-x-0 top-0 z-10 flex justify-center pt-2">
            <div className="h-5 w-24 rounded-full bg-bg/80" />
          </div>
          <div className="flex h-[min(720px,78dvh)] flex-col pt-5">{children}</div>
        </div>
      </div>
    </div>
  );
}
