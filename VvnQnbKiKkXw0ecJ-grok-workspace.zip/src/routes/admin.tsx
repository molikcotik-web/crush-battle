import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  ArrowLeft,
  Crown,
  Radio,
  Sparkles,
  UserPlus,
  Users,
  WalletCards,
} from "lucide-react";
import {
  connectTelegram,
  getAdminOverview,
  sendBroadcast,
  setUserPremium,
} from "@/lib/bot/fns";
import { Button } from "@/components/ui/button";
import { Input, Textarea } from "@/components/ui/input";

export const Route = createFileRoute("/admin")({ component: AdminPage });

function AdminPage() {
  const [secret, setSecret] = useState("");
  const [draft, setDraft] = useState("");
  const qc = useQueryClient();
  const overview = useQuery({
    queryKey: ["admin", secret],
    queryFn: () => getAdminOverview({ data: { secret: secret || undefined } }),
  });

  const broadcast = useMutation({
    mutationFn: () =>
      sendBroadcast({ data: { secret: secret || undefined, message: draft } }),
    onSuccess: (res) => {
      toast.success(`Broadcast queued for ${res.sent} users`);
      setDraft("");
      void qc.invalidateQueries({ queryKey: ["admin"] });
    },
    onError: (err) => toast.error(err instanceof Error ? err.message : "Failed"),
  });

  const premium = useMutation({
    mutationFn: (input: { userId: string; value: boolean }) =>
      setUserPremium({
        data: { secret: secret || undefined, ...input },
      }),
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["admin"] }),
    onError: (err) => toast.error(err instanceof Error ? err.message : "Failed"),
  });

  const connect = useMutation({
    mutationFn: () => connectTelegram({ data: { secret: secret || undefined } }),
    onSuccess: (res) => {
      if (res.ok) toast.success("Webhook connected");
      else toast.error(res.error ?? "Could not connect");
    },
    onError: (err) => toast.error(err instanceof Error ? err.message : "Failed"),
  });

  const data = overview.data;

  return (
    <div className="min-h-dvh bg-bg px-4 py-6 text-fg sm:px-8">
      <div className="mx-auto max-w-6xl">
        <Link
          to="/"
          className="inline-flex h-11 items-center gap-2 text-sm text-muted hover:text-fg"
        >
          <ArrowLeft className="size-4" />
          Studio
        </Link>

        <header className="mt-6 flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-xs uppercase tracking-[0.2em] text-accent">Operations</p>
            <h1 className="mt-2 font-display text-4xl font-semibold tracking-tight">
              Admin
            </h1>
          </div>
          <div className="flex w-full max-w-sm items-center gap-2">
            <Input
              type="password"
              placeholder="Admin secret (if set)"
              value={secret}
              onChange={(e) => setSecret(e.target.value)}
              autoComplete="off"
            />
            <Button variant="secondary" onClick={() => void overview.refetch()}>
              Unlock
            </Button>
          </div>
        </header>

        {overview.isLoading ? (
          <p className="mt-10 text-muted">Loading stats…</p>
        ) : null}

        {data && data.ok === false ? (
          <p className="mt-10 text-danger">{data.error}</p>
        ) : null}

        {data && data.ok ? (
          <>
            <section className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
              <Stat icon={Users} label="Total users" value={data.stats.totalUsers} />
              <Stat icon={Sparkles} label="Active (7d)" value={data.stats.activeUsers} />
              <Stat icon={WalletCards} label="Ideas generated" value={data.stats.generatedIdeas} />
              <Stat icon={UserPlus} label="New today" value={data.stats.newToday} />
              <Stat icon={Crown} label="Premium" value={data.stats.premiumUsers} />
            </section>

            <section className="mt-8 rounded-2xl bg-surface p-5 shadow-[var(--shadow-border)]">
              <h2 className="font-display text-lg font-semibold">Generations · 14 days</h2>
              <div className="mt-4 h-56">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={data.stats.series}>
                    <defs>
                      <linearGradient id="gen" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#7dceb0" stopOpacity={0.35} />
                        <stop offset="100%" stopColor="#7dceb0" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid stroke="rgba(242,239,232,0.08)" vertical={false} />
                    <XAxis
                      dataKey="day"
                      tickFormatter={(v: string) => v.slice(5)}
                      stroke="#6e6c66"
                      fontSize={11}
                      tickLine={false}
                      axisLine={false}
                    />
                    <YAxis
                      stroke="#6e6c66"
                      fontSize={11}
                      allowDecimals={false}
                      tickLine={false}
                      axisLine={false}
                      width={28}
                    />
                    <Tooltip
                      contentStyle={{
                        background: "#131316",
                        border: "1px solid rgba(242,239,232,0.12)",
                        borderRadius: 12,
                        color: "#f2efe8",
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="generations"
                      stroke="#7dceb0"
                      fill="url(#gen)"
                      strokeWidth={2}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </section>

            <section className="mt-8 grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
              <div className="rounded-2xl bg-surface p-5 shadow-[var(--shadow-border)]">
                <h2 className="font-display text-lg font-semibold">Broadcast</h2>
                <p className="mt-1 text-sm text-muted">
                  Sends to every Telegram user. Web preview users are counted, not pinged.
                </p>
                <Textarea
                  className="mt-4"
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  placeholder="A short studio note…"
                />
                <Button
                  className="mt-3"
                  disabled={!draft.trim() || broadcast.isPending}
                  onClick={() => broadcast.mutate()}
                >
                  <Radio className="size-4" />
                  Send broadcast
                </Button>
              </div>

              <div className="rounded-2xl bg-surface p-5 shadow-[var(--shadow-border)]">
                <h2 className="font-display text-lg font-semibold">Telegram</h2>
                <p className="mt-1 text-sm text-muted">
                  {data.telegram.configured
                    ? data.telegram.username
                      ? `Connected as @${data.telegram.username}`
                      : "Token present — webhook not confirmed"
                    : "Set TELEGRAM_BOT_TOKEN to go live. The in-app chat already uses the same engine."}
                </p>
                <ul className="mt-4 space-y-1 text-xs text-subtle">
                  <li>TELEGRAM_BOT_TOKEN</li>
                  <li>TELEGRAM_WEBHOOK_SECRET</li>
                  <li>TELEGRAM_ADMIN_IDS</li>
                  <li>ADMIN_SECRET · SESSION_SECRET</li>
                </ul>
                <Button
                  variant="secondary"
                  className="mt-4"
                  disabled={!data.telegram.configured || connect.isPending}
                  onClick={() => connect.mutate()}
                >
                  Register webhook
                </Button>
              </div>
            </section>

            <section className="mt-8 overflow-x-auto rounded-2xl bg-surface shadow-[var(--shadow-border)]">
              <table className="w-full min-w-[640px] text-left text-sm">
                <thead className="text-xs uppercase tracking-wider text-subtle">
                  <tr className="border-b border-border">
                    <th className="px-4 py-3 font-medium">User</th>
                    <th className="px-4 py-3 font-medium">Runs</th>
                    <th className="px-4 py-3 font-medium">Last active</th>
                    <th className="px-4 py-3 font-medium">Plan</th>
                  </tr>
                </thead>
                <tbody>
                  {data.users.map((u) => (
                    <tr key={u.id} className="border-b border-border/60">
                      <td className="px-4 py-3">
                        <div className="font-medium">{u.first_name || "Creator"}</div>
                        <div className="text-xs text-subtle">{u.username || u.id}</div>
                      </td>
                      <td className="px-4 py-3 tabular-nums">{u.total_generations}</td>
                      <td className="px-4 py-3 text-muted">
                        {formatWhen(u.last_active_at)}
                      </td>
                      <td className="px-4 py-3">
                        <Button
                          size="sm"
                          variant={u.is_premium ? "primary" : "secondary"}
                          onClick={() =>
                            premium.mutate({ userId: u.id, value: !u.is_premium })
                          }
                        >
                          {u.is_premium ? "Premium" : "Free"}
                        </Button>
                      </td>
                    </tr>
                  ))}
                  {data.users.length === 0 ? (
                    <tr>
                      <td className="px-4 py-8 text-muted" colSpan={4}>
                        No users yet. Open the studio chat to create the first one.
                      </td>
                    </tr>
                  ) : null}
                </tbody>
              </table>
            </section>
          </>
        ) : null}
      </div>
    </div>
  );
}

function Stat({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Users;
  label: string;
  value: number;
}) {
  return (
    <div className="rounded-xl bg-surface px-4 py-4 shadow-[var(--shadow-border)]">
      <Icon className="size-4 text-accent" />
      <p className="mt-3 font-display text-3xl font-semibold tabular-nums">{value}</p>
      <p className="mt-1 text-xs text-muted">{label}</p>
    </div>
  );
}

function formatWhen(value: string) {
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return value;
  return d.toLocaleString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}
