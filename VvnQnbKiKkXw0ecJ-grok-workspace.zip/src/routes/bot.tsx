import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { TelegramChat } from "@/components/telegram/chat";

export const Route = createFileRoute("/bot")({ component: BotPage });

function BotPage() {
  return (
    <div className="flex min-h-dvh flex-col bg-bg">
      <div className="flex items-center gap-3 px-4 py-3">
        <Link
          to="/"
          className="inline-flex h-11 items-center gap-2 text-sm text-muted hover:text-fg"
        >
          <ArrowLeft className="size-4" />
          Studio
        </Link>
      </div>
      <div className="mx-auto flex w-full max-w-lg flex-1 flex-col px-3 pb-4">
        <div className="min-h-0 flex-1 overflow-hidden rounded-2xl shadow-[var(--shadow-border)]">
          <TelegramChat />
        </div>
      </div>
    </div>
  );
}
