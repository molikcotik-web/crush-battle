import { createFileRoute, Link } from "@tanstack/react-router";
import { Clapperboard, LayoutDashboard, Sparkles, TimerReset, WalletCards } from "lucide-react";
import { TelegramChat } from "@/components/telegram/chat";
import { PhoneFrame } from "@/components/telegram/phone-frame";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <div className="relative min-h-dvh overflow-hidden bg-bg text-fg">
      <div className="pointer-events-none absolute inset-0 film-grain opacity-40" />
      <div className="pointer-events-none absolute -left-24 top-[-8rem] h-[28rem] w-[28rem] rounded-full bg-accent/8 blur-3xl" />
      <div className="relative mx-auto flex w-full max-w-6xl flex-col px-4 pb-16 pt-5 sm:px-6">
        <nav className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <span className="grid size-9 place-items-center rounded-md bg-elevated shadow-[var(--shadow-border)]">
              <Clapperboard className="size-4 text-accent" />
            </span>
            <span className="font-display text-sm font-semibold tracking-tight">
              Video Ideas Bot
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Link
              to="/bot"
              className="hidden h-11 items-center rounded-md px-3 text-sm text-muted hover:text-fg sm:inline-flex"
            >
              Open chat
            </Link>
            <Link to="/admin">
              <Button variant="secondary" size="sm">
                <LayoutDashboard className="size-4" />
                Admin
              </Button>
            </Link>
          </div>
        </nav>

        <section className="mt-10 grid items-start gap-12 lg:mt-14 lg:grid-cols-[1.05fr_0.95fr]">
          <div>
            <p className="rise-in text-xs font-medium uppercase tracking-[0.22em] text-accent">
              TikTok · Shorts · Reels
            </p>
            <h1 className="rise-in-2 mt-4 max-w-[14ch] font-display text-4xl font-semibold leading-[1.05] tracking-[-0.03em] sm:text-6xl">
              Never run out of viral ideas.
            </h1>
            <p className="rise-in-3 mt-5 max-w-md text-base leading-relaxed text-muted sm:text-lg">
              A Telegram studio that writes five complete concepts on command —
              hook, shot list, script, caption, hashtags, length and CTA.
              Three free generations a day. Premium never sleeps.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <a href="#studio">
                <Button size="lg">Try it in the chat</Button>
              </a>
              <Link to="/admin">
                <Button variant="secondary" size="lg">
                  Open admin
                </Button>
              </Link>
            </div>
            <dl className="mt-10 grid grid-cols-3 gap-3 max-w-lg">
              {[
                ["5", "ideas / run"],
                ["3", "free daily"],
                ["2", "languages"],
              ].map(([n, l]) => (
                <div
                  key={l}
                  className="rounded-xl bg-surface px-3 py-3 shadow-[var(--shadow-border)]"
                >
                  <dt className="font-display text-2xl font-semibold tabular-nums">{n}</dt>
                  <dd className="mt-1 text-xs text-muted">{l}</dd>
                </div>
              ))}
            </dl>
          </div>

          <div id="studio" className="lg:pt-2">
            <PhoneFrame>
              <TelegramChat compact />
            </PhoneFrame>
            <p className="mt-3 text-center text-xs text-subtle">
              Live bot. Same engine the Telegram webhook uses.
            </p>
          </div>
        </section>

        <section className="mt-20 grid gap-4 sm:grid-cols-3">
          {features.map((f) => (
            <article
              key={f.title}
              className="rounded-2xl bg-surface p-5 shadow-[var(--shadow-border)]"
            >
              <f.icon className="size-5 text-accent" />
              <h2 className="mt-4 font-display text-lg font-semibold">{f.title}</h2>
              <p className="mt-2 text-sm leading-relaxed text-muted">{f.body}</p>
            </article>
          ))}
        </section>

        <section className="mt-16 rounded-2xl bg-surface p-6 shadow-[var(--shadow-border)] sm:p-8">
          <h2 className="font-display text-2xl font-semibold">How a generation works</h2>
          <ol className="mt-6 grid gap-6 sm:grid-cols-3">
            {steps.map((s, i) => (
              <li key={s.title}>
                <span className="font-display text-sm tabular-nums text-accent">
                  0{i + 1}
                </span>
                <h3 className="mt-2 font-medium">{s.title}</h3>
                <p className="mt-1 text-sm text-muted">{s.body}</p>
              </li>
            ))}
          </ol>
        </section>
      </div>
    </div>
  );
}

const features = [
  {
    icon: Sparkles,
    title: "Production-ready packs",
    body: "Each idea ships with a 2–3 second hook, full short script, caption, 5–10 hashtags and a call to action.",
  },
  {
    icon: TimerReset,
    title: "Daily limit, honest premium",
    body: "Three free generations reset at midnight UTC. Premium users generate without a cap. Saved ideas stay in your library.",
  },
  {
    icon: WalletCards,
    title: "Telegram-native",
    body: "Inline menus, webhook, admin broadcast. Point TELEGRAM_BOT_TOKEN at this app and the same chat goes live on Telegram.",
  },
];

const steps = [
  {
    title: "Brief",
    body: "Pick platform, niche, language and style — faceless, talking, gameplay, story or cinematic.",
  },
  {
    title: "Write",
    body: "The studio returns five distinct concepts. Generate more on the same brief if the first batch is cold.",
  },
  {
    title: "Ship",
    body: "Save keepers, copy the pack, film. Daily and trending menus refill without burning a credit.",
  },
];
