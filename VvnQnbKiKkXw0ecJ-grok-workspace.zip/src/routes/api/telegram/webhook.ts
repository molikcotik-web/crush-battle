import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/telegram/webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { processTelegramUpdate, verifyTelegramSecret } = await import(
          "@/lib/bot/telegram.server"
        );
        const secret = request.headers.get("x-telegram-bot-api-secret-token");
        if (!verifyTelegramSecret(secret)) {
          return new Response("forbidden", { status: 403 });
        }
        let update: unknown;
        try {
          update = await request.json();
        } catch {
          return new Response("bad request", { status: 400 });
        }
        if (!update || typeof update !== "object" || !("update_id" in update)) {
          return new Response("bad request", { status: 400 });
        }
        try {
          await processTelegramUpdate(
            update as Parameters<typeof processTelegramUpdate>[0],
          );
        } catch (err) {
          console.error("[telegram] update failed", err);
        }
        return Response.json({ ok: true });
      },
    },
  },
});
