import {
  adminIds,
  botToken,
  telegramUserId,
  webhookSecret,
} from "./session.server";
import { handleAction } from "./engine.server";
import { getSql } from "@/lib/db";
import type { ChatMessage, InlineButton } from "./types";
import { getUser, setPremium } from "./users.server";

const API = "https://api.telegram.org";

type TelegramUser = {
  id: number;
  username?: string;
  first_name?: string;
  last_name?: string;
};

type TelegramUpdate = {
  update_id: number;
  message?: {
    message_id: number;
    text?: string;
    chat: { id: number; type: string };
    from?: TelegramUser;
  };
  callback_query?: {
    id: string;
    data?: string;
    from: TelegramUser;
    message?: { chat: { id: number }; message_id: number };
  };
};

async function tg(method: string, body: Record<string, unknown>): Promise<boolean> {
  const token = botToken();
  if (!token) return false;
  try {
    const res = await fetch(`${API}/bot${token}/${method}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    return res.ok;
  } catch {
    return false;
  }
}

function markup(buttons?: InlineButton[][]) {
  if (!buttons?.length) return undefined;
  return {
    inline_keyboard: buttons.map((row) =>
      row.map((b) => ({ text: b.text, callback_data: b.action.slice(0, 64) })),
    ),
  };
}

async function sendChat(chatId: number, messages: ChatMessage[]) {
  for (const m of messages) {
    await tg("sendMessage", {
      chat_id: chatId,
      text: m.text.slice(0, 3900),
      reply_markup: markup(m.buttons),
    });
  }
}

export function verifyTelegramSecret(header: string | null): boolean {
  const expected = webhookSecret();
  if (!expected) return true;
  return header === expected;
}

export async function processTelegramUpdate(update: TelegramUpdate): Promise<void> {
  const sql = await getSql();
  const seen = await sql<{ update_id: number }>`
    insert into telegram_updates (update_id)
    values (${update.update_id})
    on conflict (update_id) do nothing
    returning update_id
  `;
  if (!seen.length) return;

  if (update.callback_query) {
    const cq = update.callback_query;
    await tg("answerCallbackQuery", { callback_query_id: cq.id });
    const from = cq.from;
    const chatId = cq.message?.chat.id ?? from.id;
    const userId = telegramUserId(from.id);
    const data = cq.data || "menu";
    const result = await handleAction({
      userId,
      action: data,
      telegramId: String(from.id),
      username: from.username,
      firstName: from.first_name,
    });
    await sendChat(chatId, result.messages);
    return;
  }

  const message = update.message;
  if (!message?.from) return;
  const from = message.from;
  const text = (message.text ?? "").trim();
  const userId = telegramUserId(from.id);
  const chatId = message.chat.id;

  if (text.startsWith("/stats") || text.startsWith("/broadcast") || text.startsWith("/premium")) {
    const admins = adminIds();
    const user = await getUser(userId);
    const allowed = admins.includes(String(from.id)) || Boolean(user?.is_admin);
    if (!allowed) {
      await tg("sendMessage", { chat_id: chatId, text: "Admin only." });
      return;
    }
    if (text.startsWith("/premium")) {
      const target = text.split(/\s+/)[1];
      if (!target) {
        await tg("sendMessage", { chat_id: chatId, text: "Usage: /premium <telegram_id>" });
        return;
      }
      const tid = target.startsWith("tg:") ? target : `tg:${target}`;
      await setPremium(tid, true);
      await tg("sendMessage", { chat_id: chatId, text: `Premium granted to ${tid}` });
      return;
    }
    if (text.startsWith("/broadcast")) {
      const payload = text.replace(/^\/broadcast(@\w+)?\s*/, "").trim();
      if (!payload) {
        await tg("sendMessage", { chat_id: chatId, text: "Usage: /broadcast <message>" });
        return;
      }
      const { broadcast } = await import("./admin.server");
      const sent = await broadcast(payload);
      await tg("sendMessage", { chat_id: chatId, text: `Broadcast sent to ${sent} users.` });
      return;
    }
    const { getAdminStats } = await import("./admin.server");
    const stats = await getAdminStats();
    await tg("sendMessage", {
      chat_id: chatId,
      text: [
        "Admin",
        `Users: ${stats.totalUsers}`,
        `Active (7d): ${stats.activeUsers}`,
        `Generated: ${stats.generatedIdeas}`,
        `New today: ${stats.newToday}`,
        `Premium: ${stats.premiumUsers}`,
      ].join("\n"),
    });
    return;
  }

  const action = text.startsWith("/") ? text.split(/\s+/)[0]!.toLowerCase() : text;
  const result = await handleAction({
    userId,
    action,
    telegramId: String(from.id),
    username: from.username,
    firstName: from.first_name,
  });
  await sendChat(chatId, result.messages);
}

export async function sendTelegramMessage(telegramId: string, text: string): Promise<boolean> {
  const numeric = telegramId.replace(/^tg:/, "");
  if (!/^\d+$/.test(numeric)) return false;
  return tg("sendMessage", { chat_id: Number(numeric), text: text.slice(0, 3900) });
}

export async function setTelegramWebhook(publicUrl: string): Promise<{ ok: boolean; error?: string }> {
  const token = botToken();
  if (!token) return { ok: false, error: "TELEGRAM_BOT_TOKEN is not set" };
  const secret = webhookSecret();
  const webhookUrl = `${publicUrl.replace(/\/$/, "")}/api/telegram/webhook`;
  try {
    const res = await fetch(`${API}/bot${token}/setWebhook`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        url: webhookUrl,
        secret_token: secret,
        allowed_updates: ["message", "callback_query"],
        drop_pending_updates: false,
      }),
    });
    const body = (await res.json()) as { ok?: boolean; description?: string };
    if (!body.ok) return { ok: false, error: body.description ?? "setWebhook failed" };
    return { ok: true };
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : "setWebhook failed" };
  }
}

export async function telegramStatus(): Promise<{
  configured: boolean;
  username: string | null;
}> {
  const token = botToken();
  if (!token) return { configured: false, username: null };
  try {
    const res = await fetch(`${API}/bot${token}/getMe`);
    const body = (await res.json()) as {
      ok?: boolean;
      result?: { username?: string };
    };
    if (!body.ok) return { configured: true, username: null };
    return { configured: true, username: body.result?.username ?? null };
  } catch {
    return { configured: true, username: null };
  }
}
