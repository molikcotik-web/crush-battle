import {
  type Language,
  type Niche,
  type Platform,
  type Style,
  type VideoIdea,
} from "./types";

export const PLATFORM_META: Record<
  Platform,
  { label: string; emoji: string; short: string }
> = {
  tiktok: { label: "TikTok", emoji: "🎵", short: "TikTok" },
  shorts: { label: "YouTube Shorts", emoji: "▶️", short: "Shorts" },
  reels: { label: "Instagram Reels", emoji: "📸", short: "Reels" },
};

export const NICHE_META: Record<Niche, { label: string; emoji: string; uk: string }> = {
  gaming: { label: "Gaming", emoji: "🎮", uk: "Ігри" },
  memes: { label: "Memes", emoji: "😂", uk: "Меми" },
  cars: { label: "Cars", emoji: "🚗", uk: "Авто" },
  ai: { label: "AI", emoji: "🤖", uk: "ШІ" },
  funny: { label: "Funny videos", emoji: "🤣", uk: "Приколи" },
  lifestyle: { label: "Lifestyle", emoji: "✨", uk: "Лайфстайл" },
  crypto: { label: "Crypto", emoji: "₿", uk: "Крипта" },
  education: { label: "Education", emoji: "📚", uk: "Освіта" },
  other: { label: "Other", emoji: "🎲", uk: "Інше" },
};

export const STYLE_META: Record<Style, { label: string; emoji: string; uk: string }> = {
  faceless: { label: "Faceless", emoji: "🫥", uk: "Без обличчя" },
  talking: { label: "Talking", emoji: "🗣️", uk: "В кадрі" },
  gameplay: { label: "Gameplay", emoji: "🕹️", uk: "Геймплей" },
  storytelling: { label: "Storytelling", emoji: "📖", uk: "Історія" },
  cinematic: { label: "Cinematic", emoji: "🎥", uk: "Кінематограф" },
};

export const LANG_META: Record<Language, { label: string; native: string; flag: string }> = {
  en: { label: "English", native: "English", flag: "🇬🇧" },
  uk: { label: "Ukrainian", native: "Українська", flag: "🇺🇦" },
};

export function nicheLabel(niche: string, language: Language): string {
  const meta = NICHE_META[niche as Niche];
  if (!meta) return niche;
  return language === "uk" ? meta.uk : meta.label;
}

export function styleLabel(style: Style, language: Language): string {
  const meta = STYLE_META[style];
  return language === "uk" ? meta.uk : meta.label;
}

export function formatIdeaPlain(idea: VideoIdea): string {
  const tags = idea.hashtags
    .map((t) => (t.startsWith("#") ? t : `#${t}`))
    .join(" ");
  return [
    idea.title,
    "",
    `Hook (0–3s): ${idea.hook}`,
    "",
    `What happens: ${idea.whatHappens}`,
    "",
    "Script:",
    idea.script,
    "",
    `Caption: ${idea.caption}`,
    "",
    tags,
    "",
    `Length: ${idea.length}`,
    `CTA: ${idea.cta}`,
  ].join("\n");
}

export function formatIdeaHtml(idea: VideoIdea, index: number): string {
  const tags = idea.hashtags
    .map((t) => (t.startsWith("#") ? t : `#${t}`))
    .join(" ");
  return [
    `<b>${index}. ${escapeHtml(idea.title)}</b>`,
    "",
    `🪝 <b>Hook (0–3s)</b>\n${escapeHtml(idea.hook)}`,
    "",
    `🎬 <b>What happens</b>\n${escapeHtml(idea.whatHappens)}`,
    "",
    `📝 <b>Script</b>\n${escapeHtml(idea.script)}`,
    "",
    `💬 <b>Caption</b>\n${escapeHtml(idea.caption)}`,
    "",
    escapeHtml(tags),
    "",
    `⏱ ${escapeHtml(idea.length)}   ·   📣 ${escapeHtml(idea.cta)}`,
  ].join("\n");
}

export function escapeHtml(value: string): string {
  return value
    .replaceAll("&", "&")
    .replaceAll("<", "<")
    .replaceAll(">", ">");
}
