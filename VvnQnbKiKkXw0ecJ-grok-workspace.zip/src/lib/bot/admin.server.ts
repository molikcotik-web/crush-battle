import { getSql } from "@/lib/db";
import { adminSecret, isPreview } from "./session.server";
import { sendTelegramMessage } from "./telegram.server";

export type AdminStats = {
  totalUsers: number;
  activeUsers: number;
  generatedIdeas: number;
  newToday: number;
  premiumUsers: number;
  savedIdeas: number;
  series: Array<{ day: string; generations: number }>;
};

export function assertAdmin(secret: string | undefined): boolean {
  const expected = adminSecret();
  if (!expected) return isPreview();
  return Boolean(secret) && secret === expected;
}

export async function getAdminStats(): Promise<AdminStats> {
  const sql = await getSql();
  const [total] = await sql<{ n: number }>`select count(*)::int as n from bot_users`;
  const [active] = await sql<{ n: number }>`
    select count(*)::int as n from bot_users
    where last_active_at > now() - interval '7 days'
  `;
  const ideaRows = await sql<{ ideas: unknown }>`select ideas from generations`;
  const generatedIdeas = ideaRows.reduce((sum, row) => {
    const ideas = row.ideas;
    return sum + (Array.isArray(ideas) ? ideas.length : 0);
  }, 0);
  const [newToday] = await sql<{ n: number }>`
    select count(*)::int as n from bot_users
    where created_at::date = (now() at time zone 'utc')::date
  `;
  const [premium] = await sql<{ n: number }>`
    select count(*)::int as n from bot_users where is_premium = true
  `;
  const [saved] = await sql<{ n: number }>`select count(*)::int as n from saved_ideas`;
  const series = await sql<{ day: string; generations: number }>`
    select to_char(d::date, 'YYYY-MM-DD') as day,
           coalesce((
             select count(*)::int from generations g
             where g.created_at::date = d::date
           ), 0) as generations
    from generate_series(
      (now() at time zone 'utc')::date - 13,
      (now() at time zone 'utc')::date,
      interval '1 day'
    ) as d
  `;
  return {
    totalUsers: Number(total?.n ?? 0),
    activeUsers: Number(active?.n ?? 0),
    generatedIdeas,
    newToday: Number(newToday?.n ?? 0),
    premiumUsers: Number(premium?.n ?? 0),
    savedIdeas: Number(saved?.n ?? 0),
    series,
  };
}

export async function listUsers(limit = 40) {
  const sql = await getSql();
  return sql<{
    id: string;
    first_name: string | null;
    username: string | null;
    is_premium: boolean;
    total_generations: number;
    last_active_at: string;
    created_at: string;
  }>`
    select id, first_name, username, is_premium, total_generations, last_active_at, created_at
    from bot_users
    order by last_active_at desc
    limit ${limit}
  `;
}

export async function broadcast(message: string): Promise<number> {
  const sql = await getSql();
  const users = await sql<{ id: string; telegram_id: string | null }>`
    select id, telegram_id from bot_users
  `;
  let sent = 0;
  for (const u of users) {
    if (u.telegram_id) {
      const ok = await sendTelegramMessage(u.telegram_id, message);
      if (ok) sent += 1;
    } else {
      sent += 1;
    }
  }
  await sql`
    insert into broadcasts (message, sent_count)
    values (${message}, ${sent})
  `;
  return sent;
}

export async function togglePremium(userId: string, value: boolean) {
  const sql = await getSql();
  await sql`update bot_users set is_premium = ${value} where id = ${userId}`;
}
