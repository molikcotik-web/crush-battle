import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const tokenField = z.string().max(800).optional();

export const ensureWebSession = createServerFn({ method: "POST" })
  .validator(z.object({ token: tokenField }))
  .handler(async ({ data }) => {
    const { verifySessionToken, issueSessionToken, newWebUserId } = await import(
      "./session.server"
    );
    const { upsertUser, loadSession, toPublic } = await import("./users.server");
    const existing = verifySessionToken(data.token);
    const userId = existing ?? newWebUserId();
    const user = await upsertUser({ id: userId, firstName: "Creator" });
    const session = await loadSession(userId);
    return {
      token: issueSessionToken(userId),
      user: await toPublic(user),
      messages: session.messages,
    };
  });

export const sendBotAction = createServerFn({ method: "POST" })
  .validator(
    z.object({
      token: z.string().min(8).max(800),
      action: z.string().min(1).max(200),
    }),
  )
  .handler(async ({ data }) => {
    const { verifySessionToken } = await import("./session.server");
    const userId = verifySessionToken(data.token);
    if (!userId) throw new Error("Session expired. Reload the page.");
    const { handleAction } = await import("./engine.server");
    return handleAction({ userId, action: data.action, firstName: "Creator" });
  });

export const getAdminOverview = createServerFn({ method: "POST" })
  .validator(z.object({ secret: z.string().max(200).optional() }))
  .handler(async ({ data }) => {
    const { assertAdmin, getAdminStats, listUsers } = await import("./admin.server");
    const { telegramStatus } = await import("./telegram.server");
    const { adminSecret, isPreview } = await import("./session.server");
    if (!assertAdmin(data.secret)) {
      return { ok: false as const, error: "Admin secret required" };
    }
    const [stats, users, telegram] = await Promise.all([
      getAdminStats(),
      listUsers(),
      telegramStatus(),
    ]);
    return {
      ok: true as const,
      stats,
      users,
      telegram,
      needsSecret: Boolean(adminSecret()) && !isPreview(),
    };
  });

export const sendBroadcast = createServerFn({ method: "POST" })
  .validator(
    z.object({
      secret: z.string().max(200).optional(),
      message: z.string().min(1).max(1000),
    }),
  )
  .handler(async ({ data }) => {
    const { assertAdmin, broadcast } = await import("./admin.server");
    if (!assertAdmin(data.secret)) throw new Error("Unauthorized");
    const sent = await broadcast(data.message.trim());
    return { sent };
  });

export const setUserPremium = createServerFn({ method: "POST" })
  .validator(
    z.object({
      secret: z.string().max(200).optional(),
      userId: z.string().min(1).max(80),
      value: z.boolean(),
    }),
  )
  .handler(async ({ data }) => {
    const { assertAdmin, togglePremium } = await import("./admin.server");
    if (!assertAdmin(data.secret)) throw new Error("Unauthorized");
    await togglePremium(data.userId, data.value);
    return { ok: true };
  });

export const connectTelegram = createServerFn({ method: "POST" })
  .validator(z.object({ secret: z.string().max(200).optional() }))
  .handler(async ({ data }) => {
    const { assertAdmin } = await import("./admin.server");
    const { setTelegramWebhook } = await import("./telegram.server");
    const { getRequest } = await import("@tanstack/react-start/server");
    if (!assertAdmin(data.secret)) throw new Error("Unauthorized");
    const request = getRequest();
    const url = new URL(request.url);
    const host = request.headers.get("x-forwarded-host") ?? url.host;
    const proto = request.headers.get("x-forwarded-proto") ?? url.protocol.replace(":", "");
    return setTelegramWebhook(`${proto}://${host}`);
  });
