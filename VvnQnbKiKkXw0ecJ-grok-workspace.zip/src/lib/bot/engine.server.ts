import { randomUUID } from "node:crypto";
import {
  LANGUAGES,
  NICHES,
  PLATFORMS,
  STYLES,
  type ChatMessage,
  type InlineButton,
  type Language,
  type Platform,
  type PublicUser,
  type SessionState,
  type Style,
  type VideoIdea,
} from "./types";
import {
  LANG_META,
  NICHE_META,
  PLATFORM_META,
  STYLE_META,
  formatIdeaHtml,
  formatIdeaPlain,
  nicheLabel,
  styleLabel,
} from "./catalog";
import {
  consumeGeneration,
  getUser,
  loadSession,
  remainingFor,
  saveSession,
  setPremium,
  setUserLanguage,
  setUserNiche,
  toPublic,
  upsertUser,
  type BotUserRow,
} from "./users.server";
import {
  cachedPack,
  deleteSaved,
  generateIdeas,
  getGeneration,
  listSaved,
  persistGeneration,
  saveIdea,
} from "./generate.server";
import { isPreview } from "./session.server";

function msg(
  text: string,
  extra?: Partial<ChatMessage>,
): ChatMessage {
  return {
    id: randomUUID(),
    role: extra?.role ?? "bot",
    text,
    createdAt: new Date().toISOString(),
    idea: extra?.idea,
    buttons: extra?.buttons,
  };
}

function mainMenu(language: Language): InlineButton[][] {
  if (language === "uk") {
    return [
      [{ text: "🎬 Згенерувати ідею", action: "generate" }],
      [
        { text: "🔥 Тренди", action: "trending" },
        { text: "🎯 Ніша", action: "choose_niche" },
      ],
      [
        { text: "📅 Ідеї дня", action: "daily" },
        { text: "💡 Збережені", action: "saved" },
      ],
      [{ text: "⚙️ Налаштування", action: "settings" }],
    ];
  }
  return [
    [{ text: "🎬 Generate Idea", action: "generate" }],
    [
      { text: "🔥 Trending Ideas", action: "trending" },
      { text: "🎯 Choose Niche", action: "choose_niche" },
    ],
    [
      { text: "📅 Daily Ideas", action: "daily" },
      { text: "💡 My Saved Ideas", action: "saved" },
    ],
    [{ text: "⚙️ Settings", action: "settings" }],
  ];
}

function welcome(language: Language, name: string): string {
  if (language === "uk") {
    return `Привіт, ${name}. Я Video Ideas Bot — студія коротких відео в кишені.\n\nЗберу 5 ідей під TikTok, YouTube Shorts або Reels: заголовок, гачок на 2–3 с, сценарій, опис і хештеги.\n\nОбери дію:`;
  }
  return `Hey ${name}. I’m Video Ideas Bot — a short-form studio in your pocket.\n\nI’ll write 5 ideas for TikTok, YouTube Shorts or Reels: title, 2–3s hook, script, caption and hashtags.\n\nPick a move:`;
}

function platformButtons(): InlineButton[][] {
  return [
    PLATFORMS.map((p) => ({
      text: `${PLATFORM_META[p].emoji} ${PLATFORM_META[p].short}`,
      action: `platform:${p}`,
    })),
    [{ text: "⬅️ Back", action: "menu" }],
  ];
}

function nicheButtons(language: Language): InlineButton[][] {
  const rows: InlineButton[][] = [];
  for (let i = 0; i < NICHES.length; i += 3) {
    rows.push(
      NICHES.slice(i, i + 3).map((n) => ({
        text: `${NICHE_META[n].emoji} ${language === "uk" ? NICHE_META[n].uk : NICHE_META[n].label}`,
        action: `niche:${n}`,
      })),
    );
  }
  rows.push([{ text: "⬅️ Back", action: "menu" }]);
  return rows;
}

function languageButtons(): InlineButton[][] {
  return [
    LANGUAGES.map((l) => ({
      text: `${LANG_META[l].flag} ${LANG_META[l].native}`,
      action: `lang:${l}`,
    })),
    [{ text: "⬅️ Back", action: "menu" }],
  ];
}

function styleButtons(language: Language): InlineButton[][] {
  const row1 = STYLES.slice(0, 3).map((s) => ({
    text: `${STYLE_META[s].emoji} ${styleLabel(s, language)}`,
    action: `style:${s}`,
  }));
  const row2 = STYLES.slice(3).map((s) => ({
    text: `${STYLE_META[s].emoji} ${styleLabel(s, language)}`,
    action: `style:${s}`,
  }));
  return [row1, row2, [{ text: "⬅️ Back", action: "menu" }]];
}

function ideaActions(generationId: number, index: number, language: Language): InlineButton[][] {
  const save = language === "uk" ? "❤️ Зберегти" : "❤️ Save";
  const copy = language === "uk" ? "📋 Копіювати" : "📋 Copy";
  return [
    [
      { text: save, action: `save:${generationId}:${index}` },
      { text: copy, action: `copy:${generationId}:${index}` },
    ],
  ];
}

function afterBatch(generationId: number, language: Language): InlineButton[][] {
  const more = language === "uk" ? "🔄 Ще 5 ідей" : "🔄 Generate More";
  const back = language === "uk" ? "⬅️ Меню" : "⬅️ Back";
  return [
    [
      { text: more, action: `more:${generationId}` },
      { text: back, action: "menu" },
    ],
  ];
}

function limitText(user: BotUserRow): string {
  if (user.is_premium) {
    return user.language === "uk"
      ? "Premium: безлімітні генерації."
      : "Premium: unlimited generations.";
  }
  const left = remainingFor(user);
  return user.language === "uk"
    ? `Залишилось безкоштовних генерацій сьогодні: ${left}/3.`
    : `Free generations left today: ${left}/3.`;
}

async function pushAndSave(
  userId: string,
  state: SessionState,
  incoming: ChatMessage[],
): Promise<ChatMessage[]> {
  state.messages = [...state.messages, ...incoming].slice(-80);
  await saveSession(userId, state);
  return incoming;
}

export type EngineResult = {
  messages: ChatMessage[];
  user: PublicUser;
  copyText?: string;
};

export async function handleAction(input: {
  userId: string;
  action: string;
  telegramId?: string;
  username?: string;
  firstName?: string;
}): Promise<EngineResult> {
  const user = await upsertUser({
    id: input.userId,
    telegramId: input.telegramId,
    username: input.username,
    firstName: input.firstName,
  });
  const state = await loadSession(input.userId);
  const language = (user.language === "uk" ? "uk" : "en") as Language;
  const action = input.action.trim();

  const reply = async (
    messages: ChatMessage[],
    next?: Partial<SessionState>,
    copyText?: string,
  ): Promise<EngineResult> => {
    if (next) Object.assign(state, next);
    const added = await pushAndSave(input.userId, state, messages);
    const fresh = await getUser(input.userId);
    return {
      messages: added,
      user: await toPublic(fresh ?? user),
      copyText,
    };
  };

  if (action === "/start" || action === "start" || action === "menu") {
    state.step = "idle";
    state.draft = {};
    return reply(
      [
        msg(welcome(language, user.first_name || "Creator"), {
          buttons: mainMenu(language),
        }),
      ],
      { step: "idle", draft: {} },
    );
  }

  if (state.step === "awaiting_custom_niche" && !action.includes(":")) {
    const niche = action.slice(0, 40);
    await setUserNiche(input.userId, niche);
    state.draft.niche = niche;
    if (!state.draft.platform) {
      return reply(
        [
          msg(
            language === "uk" ? `Ніша: ${niche}. Тепер платформа:` : `Niche set: ${niche}. Now pick a platform:`,
            { buttons: platformButtons() },
          ),
        ],
        { step: "gen_platform", draft: state.draft },
      );
    }
    return reply(
      [
        msg(
          language === "uk" ? `Ніша: ${niche}. Мова відео?` : `Niche set: ${niche}. Video language?`,
          { buttons: languageButtons() },
        ),
      ],
      { step: "gen_language", draft: state.draft },
    );
  }

  if (action === "generate") {
    state.draft = { language, niche: user.niche ?? undefined };
    return reply(
      [
        msg(
          language === "uk"
            ? "Куди знімаємо? TikTok, Shorts чи Reels."
            : "Where should this live — TikTok, Shorts or Reels?",
          { buttons: platformButtons() },
        ),
      ],
      { step: "gen_platform", draft: state.draft },
    );
  }

  if (action.startsWith("platform:")) {
    const platform = action.slice("platform:".length) as Platform;
    if (!PLATFORMS.includes(platform)) {
      return reply([msg(language === "uk" ? "Невідома платформа." : "Unknown platform.")]);
    }
    state.draft.platform = platform;
    return reply(
      [
        msg(
          language === "uk" ? "Яка ніша?" : "Which niche?",
          { buttons: nicheButtons(language) },
        ),
      ],
      { step: "gen_niche", draft: state.draft },
    );
  }

  if (action === "choose_niche") {
    return reply(
      [
        msg(
          language === "uk"
            ? "Обери нішу за замовчуванням. Її підставлю в генерації."
            : "Set a default niche. I’ll pre-fill it on generate.",
          { buttons: nicheButtons(language) },
        ),
      ],
      { step: "idle" },
    );
  }

  if (action.startsWith("niche:")) {
    const niche = action.slice("niche:".length);
    if (niche === "other" && state.step === "gen_niche") {
      return reply(
        [
          msg(
            language === "uk"
              ? "Напиши свою нішу кількома словами."
              : "Type your niche in a few words.",
          ),
        ],
        { step: "awaiting_custom_niche", draft: state.draft },
      );
    }
    await setUserNiche(input.userId, niche);
    state.draft.niche = niche;
    if (state.step === "gen_niche" || state.draft.platform) {
      return reply(
        [
          msg(
            language === "uk" ? "Мова сценарію?" : "Script language?",
            { buttons: languageButtons() },
          ),
        ],
        { step: "gen_language", draft: state.draft },
      );
    }
    return reply(
      [
        msg(
          language === "uk"
            ? `Нішу збережено: ${nicheLabel(niche, language)}.`
            : `Niche saved: ${nicheLabel(niche, language)}.`,
          { buttons: mainMenu(language) },
        ),
      ],
      { step: "idle" },
    );
  }

  if (action.startsWith("lang:")) {
    const nextLang = action.slice("lang:".length) as Language;
    if (!LANGUAGES.includes(nextLang)) {
      return reply([msg("Unknown language.")]);
    }
    state.draft.language = nextLang;
    await setUserLanguage(input.userId, nextLang);
    if (state.step === "gen_language" || state.draft.platform) {
      return reply(
        [
          msg(
            nextLang === "uk" ? "Стиль відео?" : "Video style?",
            { buttons: styleButtons(nextLang) },
          ),
        ],
        { step: "gen_style", draft: state.draft },
      );
    }
    return reply(
      [
        msg(
          nextLang === "uk" ? "Мову оновлено." : "Language updated.",
          { buttons: mainMenu(nextLang) },
        ),
      ],
      { step: "idle" },
    );
  }

  if (action.startsWith("style:")) {
    const style = action.slice("style:".length) as Style;
    if (!STYLES.includes(style)) {
      return reply([msg(language === "uk" ? "Невідомий стиль." : "Unknown style.")]);
    }
    state.draft.style = style;
    return runGeneration(input.userId, user, state, reply);
  }

  if (action.startsWith("more:")) {
    const genId = Number(action.slice("more:".length));
    const prev = Number.isFinite(genId)
      ? await getGeneration(genId, input.userId)
      : null;
    if (prev?.[0]) {
      state.draft = {
        platform: prev[0].platform,
        niche: prev[0].niche,
        language: prev[0].language,
        style: prev[0].style,
      };
    }
    return runGeneration(input.userId, user, state, reply, prev?.map((i) => i.title));
  }

  if (action.startsWith("save:")) {
    const [, genRaw, idxRaw] = action.split(":");
    const genId = Number(genRaw);
    const idx = Number(idxRaw);
    const ideas = await getGeneration(genId, input.userId);
    const idea = ideas?.[idx];
    if (!idea) {
      return reply([
        msg(language === "uk" ? "Ідею не знайдено." : "Idea not found.", {
          buttons: mainMenu(language),
        }),
      ]);
    }
    await saveIdea(input.userId, idea);
    return reply([
      msg(
        language === "uk" ? `Збережено: ${idea.title}` : `Saved: ${idea.title}`,
        { buttons: afterBatch(genId, language) },
      ),
    ]);
  }

  if (action.startsWith("copy:")) {
    const [, genRaw, idxRaw] = action.split(":");
    const ideas = await getGeneration(Number(genRaw), input.userId);
    const idea = ideas?.[Number(idxRaw)];
    if (!idea) {
      return reply([msg(language === "uk" ? "Ідею не знайдено." : "Idea not found.")]);
    }
    return reply(
      [
        msg(
          language === "uk"
            ? "Готово до копіювання — текст нижче. Натисни і тримай, щоб скопіювати."
            : "Copy-ready text below. Long-press to copy.",
        ),
        msg(formatIdeaPlain(idea)),
      ],
      undefined,
      formatIdeaPlain(idea),
    );
  }

  if (action.startsWith("unsave:")) {
    const id = Number(action.slice("unsave:".length));
    await deleteSaved(input.userId, id);
    return reply([
      msg(language === "uk" ? "Видалено зі збережених." : "Removed from saved.", {
        buttons: mainMenu(language),
      }),
    ]);
  }

  if (action === "trending" || action === "daily") {
    const pack = await cachedPack(action, language);
    const header =
      action === "trending"
        ? language === "uk"
          ? "🔥 Тренди сьогодні — 5 ідей, які зараз заходять."
          : "🔥 Today’s trending pack — five ideas with heat."
        : language === "uk"
          ? "📅 Ідеї дня. Одна порція на всіх, щоб стрічка не повторювалась."
          : "📅 Daily ideas. One pack for everyone, so the feed stays fresh.";
    const messages: ChatMessage[] = [msg(header)];
    pack.forEach((idea, i) => {
      messages.push(
        msg(stripHtml(formatIdeaHtml(idea, i + 1)), { idea }),
      );
    });
    messages.push(msg(language === "uk" ? "Далі?" : "What next?", { buttons: mainMenu(language) }));
    return reply(messages, { step: "idle" });
  }

  if (action === "saved") {
    const saved = await listSaved(input.userId);
    if (!saved.length) {
      return reply([
        msg(
          language === "uk"
            ? "Поки порожньо. Згенеруй ідею і натисни ❤️."
            : "Nothing saved yet. Generate an idea and tap ❤️.",
          { buttons: mainMenu(language) },
        ),
      ]);
    }
    const messages: ChatMessage[] = [
      msg(
        language === "uk"
          ? `Збережено: ${saved.length}`
          : `Saved ideas: ${saved.length}`,
      ),
    ];
    for (const row of saved.slice(0, 8)) {
      messages.push(
        msg(stripHtml(formatIdeaHtml(row.idea, 1)), {
          idea: row.idea,
          buttons: [
            [
              {
                text: language === "uk" ? "🗑️ Видалити" : "🗑️ Remove",
                action: `unsave:${row.id}`,
              },
            ],
          ],
        }),
      );
    }
    messages.push(msg(language === "uk" ? "Меню" : "Menu", { buttons: mainMenu(language) }));
    return reply(messages);
  }

  if (action === "settings") {
    const niche = user.niche
      ? nicheLabel(user.niche, language)
      : language === "uk"
        ? "не обрана"
        : "not set";
    const premiumLine = user.is_premium
      ? language === "uk"
        ? "Статус: Premium · безліміт"
        : "Status: Premium · unlimited"
      : language === "uk"
        ? "Статус: Free · 3 генерації / день"
        : "Status: Free · 3 generations / day";
    const buttons: InlineButton[][] = [
      [
        { text: `${LANG_META.en.flag} English`, action: "setlang:en" },
        { text: `${LANG_META.uk.flag} Українська`, action: "setlang:uk" },
      ],
      [{ text: language === "uk" ? "🎯 Змінити нішу" : "🎯 Change niche", action: "choose_niche" }],
    ];
    if (isPreview() && !user.is_premium) {
      buttons.push([
        {
          text: language === "uk" ? "👑 Увімкнути Premium (демо)" : "👑 Unlock Premium (demo)",
          action: "premium_demo",
        },
      ]);
    }
    buttons.push([{ text: language === "uk" ? "⬅️ Меню" : "⬅️ Back", action: "menu" }]);
    return reply([
      msg(
        [
          language === "uk" ? "⚙️ Налаштування" : "⚙️ Settings",
          "",
          premiumLine,
          limitText(user),
          language === "uk" ? `Ніша: ${niche}` : `Niche: ${niche}`,
          language === "uk"
            ? `Мова: ${LANG_META[language].native}`
            : `Language: ${LANG_META[language].native}`,
        ].join("\n"),
        { buttons },
      ),
    ]);
  }

  if (action.startsWith("setlang:")) {
    const nextLang = action.slice("setlang:".length) as Language;
    if (!LANGUAGES.includes(nextLang)) return reply([msg("Unknown language.")]);
    await setUserLanguage(input.userId, nextLang);
    return reply([
      msg(nextLang === "uk" ? "Мову змінено на українську." : "Language set to English.", {
        buttons: mainMenu(nextLang),
      }),
    ]);
  }

  if (action === "premium_demo" && isPreview()) {
    await setPremium(input.userId, true);
    return reply([
      msg(
        language === "uk"
          ? "Premium увімкнено для цього прев’ю. Генерації без ліміту."
          : "Premium is on for this preview. Generate without a daily cap.",
        { buttons: mainMenu(language) },
      ),
    ]);
  }

  if (action === "help" || action === "/help") {
    return reply([
      msg(
        language === "uk"
          ? "Команди: /start — меню. Генеруй ідеї, зберігай, дивись тренди. 3 безкоштовні генерації на день."
          : "Commands: /start opens the menu. Generate, save, browse trends. 3 free generations a day.",
        { buttons: mainMenu(language) },
      ),
    ]);
  }

  return reply([
    msg(
      language === "uk"
        ? "Не зрозумів. Обери кнопку в меню."
        : "Didn’t catch that. Use the menu.",
      { buttons: mainMenu(language) },
    ),
  ]);
}

function stripHtml(html: string): string {
  return html
    .replaceAll("<b>", "")
    .replaceAll("</b>", "")
    .replaceAll("<br>", "\n")
    .replaceAll("&", "&")
    .replaceAll("<", "<")
    .replaceAll(">", ">");
}

type ReplyFn = (
  messages: ChatMessage[],
  next?: Partial<SessionState>,
  copyText?: string,
) => Promise<EngineResult>;

async function runGeneration(
  userId: string,
  user: BotUserRow,
  state: SessionState,
  reply: ReplyFn,
  avoidTitles?: string[],
): Promise<EngineResult> {
  const language = (state.draft.language ??
    (user.language === "uk" ? "uk" : "en")) as Language;
  const platform = state.draft.platform;
  const niche = state.draft.niche ?? user.niche ?? "lifestyle";
  const style = state.draft.style;
  if (!platform || !style) {
    return reply(
      [
        msg(
          language === "uk"
            ? "Спочатку обери платформу і стиль."
            : "Pick a platform and style first.",
          { buttons: mainMenu(language) },
        ),
      ],
      { step: "idle" },
    );
  }
  const ok = await consumeGeneration(userId);
  if (!ok) {
    return reply(
      [
        msg(
          language === "uk"
            ? "Ліміт на сьогодні вичерпано (3/3). Premium знімає ліміт — або повернись завтра."
            : "That’s the daily cap (3/3). Premium unlocks unlimited ideas — or come back tomorrow.",
          { buttons: mainMenu(language) },
        ),
      ],
      { step: "idle" },
    );
  }

  const ideas = await generateIdeas({
    platform,
    niche,
    language,
    style,
    avoidTitles,
  });
  const generationId = await persistGeneration({
    userId,
    platform,
    niche,
    language,
    style,
    ideas,
  });
  state.lastGenerationId = generationId;
  state.step = "idle";

  const header = language === "uk"
    ? `5 ідей · ${PLATFORM_META[platform].label} · ${nicheLabel(niche, language)} · ${styleLabel(style, language)}\n${limitText((await getUser(userId)) ?? user)}`
    : `5 ideas · ${PLATFORM_META[platform].label} · ${nicheLabel(niche, language)} · ${styleLabel(style, language)}\n${limitText((await getUser(userId)) ?? user)}`;

  const messages: ChatMessage[] = [msg(header)];
  ideas.forEach((idea, i) => {
    messages.push(
      msg(stripHtml(formatIdeaHtml(idea, i + 1)), {
        idea,
        buttons: ideaActions(generationId, i, language),
      }),
    );
  });
  messages.push(
    msg(language === "uk" ? "Ще за цим брифом?" : "Want another batch with this brief?", {
      buttons: afterBatch(generationId, language),
    }),
  );
  return reply(messages, { lastGenerationId: generationId, step: "idle", draft: state.draft });
}
