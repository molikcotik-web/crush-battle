import { getSql } from "@/lib/db";
import {
  DAILY_FREE_LIMIT,
  type Language,
  type PublicUser,
  type SessionState,
} from "./types";
import { adminIds } from "./session.server";

export type BotUserRow = {
  id: string;
  telegram_id: string | null;
  username: string | null;
  first_name: string | null;
  language: string;
  niche: string | null;
  is_premium: boolean;
  is_admin: boolean;
  generations_today: number;
  generation_date: string | null;
  total_generations: number;
  last_active_at: string;
  created_at: string;
};

function todayUtc(): string {
  return new Date().toISOString().slice(0, 10);
}

export async function upsertUser(input: {
  id: string;
  telegramId?: string;
  username?: string;
  firstName?: string;
  language?: Language;
}): Promise<BotUserRow> {
  const sql = await getSql();
  const isAdmin = input.telegramId
    ? adminIds().includes(input.telegramId)
    : false;
  await sql`
    insert into bot_users (id, telegram_id, username, first_name, language, is_admin)
    values (
      ${input.id},
      ${input.telegramId ?? null},
      ${input.username ?? null},
      ${input.firstName ?? "Creator"},
      ${input.language ?? "en"},
      ${isAdmin}
    )
    on conflict (id) do update set
      username = coalesce(excluded.username, bot_users.username),
      first_name = coalesce(excluded.first_name, bot_users.first_name),
      last_active_at = now(),
      is_admin = bot_users.is_admin or excluded.is_admin
  `;
  const rows = await sql<BotUserRow>`select * from bot_users where id = ${input.id}`;
  const user = rows[0];
  if (!user) throw new Error("Failed to upsert user");
  return refreshDailyWindow(user);
}

async function refreshDailyWindow(user: BotUserRow): Promise<BotUserRow> {
  const today = todayUtc();
  if (user.generation_date === today) return user;
  const sql = await getSql();
  const rows = await sql<BotUserRow>`
    update bot_users
    set generations_today = 0, generation_date = ${today}::date
    where id = ${user.id}
    returning *
  `;
  return rows[0] ?? { ...user, generations_today: 0, generation_date: today };
}

export async function getUser(id: string): Promise<BotUserRow | null> {
  const sql = await getSql();
  const rows = await sql<BotUserRow>`select * from bot_users where id = ${id}`;
  if (!rows[0]) return null;
  return refreshDailyWindow(rows[0]);
}

export function remainingFor(user: BotUserRow): number {
  if (user.is_premium) return 999;
  return Math.max(0, DAILY_FREE_LIMIT - Number(user.generations_today));
}

export async function toPublic(user: BotUserRow): Promise<PublicUser> {
  const sql = await getSql();
  const countRows = await sql<{ n: number }>`
    select count(*)::int as n from saved_ideas where user_id = ${user.id}
  `;
  return {
    id: user.id,
    firstName: user.first_name || "Creator",
    language: user.language === "uk" ? "uk" : "en",
    niche: user.niche,
    isPremium: Boolean(user.is_premium),
    isAdmin: Boolean(user.is_admin),
    remaining: remainingFor(user),
    dailyLimit: user.is_premium ? 0 : DAILY_FREE_LIMIT,
    totalGenerations: Number(user.total_generations),
    savedCount: Number(countRows[0]?.n ?? 0),
  };
}

export async function consumeGeneration(userId: string): Promise<boolean> {
  const user = await getUser(userId);
  if (!user) return false;
  if (user.is_premium) {
    const sql = await getSql();
    await sql`
      update bot_users
      set total_generations = total_generations + 1, last_active_at = now()
      where id = ${userId}
    `;
    return true;
  }
  if (remainingFor(user) <= 0) return false;
  const sql = await getSql();
  const today = todayUtc();
  const rows = await sql<{ id: string }>`
    update bot_users
    set generations_today = generations_today + 1,
        generation_date = ${today}::date,
        total_generations = total_generations + 1,
        last_active_at = now()
    where id = ${userId}
      and (is_premium = true or generations_today < ${DAILY_FREE_LIMIT})
    returning id
  `;
  return rows.length > 0;
}

export async function setUserLanguage(userId: string, language: Language) {
  const sql = await getSql();
  await sql`update bot_users set language = ${language} where id = ${userId}`;
}

export async function setUserNiche(userId: string, niche: string) {
  const sql = await getSql();
  await sql`update bot_users set niche = ${niche} where id = ${userId}`;
}

export async function setPremium(userId: string, value: boolean) {
  const sql = await getSql();
  await sql`update bot_users set is_premium = ${value} where id = ${userId}`;
}

const emptyState = (): SessionState => ({
  step: "idle",
  draft: {},
  messages: [],
});

export async function loadSession(userId: string): Promise<SessionState> {
  const sql = await getSql();
  const rows = await sql<{ state: SessionState }>`
    select state from bot_sessions where user_id = ${userId}
  `;
  const state = rows[0]?.state;
  const parsed =
    typeof state === "string" ? (JSON.parse(state) as SessionState) : state;
  if (!parsed || typeof parsed !== "object") return emptyState();
  return {
    step: parsed.step ?? "idle",
    draft: parsed.draft ?? {},
    lastGenerationId: parsed.lastGenerationId,
    messages: Array.isArray(parsed.messages) ? parsed.messages : [],
  };
}

export async function saveSession(userId: string, state: SessionState) {
  const sql = await getSql();
  const capped: SessionState = {
    ...state,
    messages: state.messages.slice(-80),
  };
  await sql`
    insert into bot_sessions (user_id, state, updated_at)
    values (${userId}, ${JSON.stringify(capped)}::jsonb, now())
    on conflict (user_id) do update set
      state = excluded.state,
      updated_at = now()
  `;
}
