import { createHmac, randomUUID, timingSafeEqual } from "node:crypto";
import { env } from "@/lib/env.server";

const TOKEN_TTL_SEC = 60 * 60 * 24 * 365;

function secret(): string {
  return (
    env("SESSION_SECRET") ??
    env("TELEGRAM_BOT_TOKEN") ??
    "vib-preview-session-key"
  );
}

function sign(payload: string): string {
  return createHmac("sha256", secret()).update(payload).digest("base64url");
}

export function issueSessionToken(userId: string): string {
  const exp = Math.floor(Date.now() / 1000) + TOKEN_TTL_SEC;
  const payload = Buffer.from(JSON.stringify({ id: userId, exp })).toString(
    "base64url",
  );
  return `${payload}.${sign(payload)}`;
}

export function verifySessionToken(token: string | undefined): string | null {
  if (!token) return null;
  const [payload, sig] = token.split(".");
  if (!payload || !sig) return null;
  const expected = sign(payload);
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length) return null;
  if (!timingSafeEqual(a, b)) return null;
  try {
    const data = JSON.parse(Buffer.from(payload, "base64url").toString("utf8")) as {
      id?: unknown;
      exp?: unknown;
    };
    if (typeof data.id !== "string" || typeof data.exp !== "number") return null;
    if (data.exp < Math.floor(Date.now() / 1000)) return null;
    if (!data.id.startsWith("web:") && !/^\d+$/.test(data.id) && !data.id.startsWith("tg:")) {
      return null;
    }
    return data.id;
  } catch {
    return null;
  }
}

export function newWebUserId(): string {
  return `web:${randomUUID()}`;
}

export function telegramUserId(telegramId: number | string): string {
  return `tg:${telegramId}`;
}

export function isPreview(): boolean {
  return !env("GROK_PROJECT_ID");
}

export function adminIds(): string[] {
  const raw = env("TELEGRAM_ADMIN_IDS") ?? "";
  return raw
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
}

export function webhookSecret(): string | undefined {
  return env("TELEGRAM_WEBHOOK_SECRET");
}

export function botToken(): string | undefined {
  return env("TELEGRAM_BOT_TOKEN");
}

export function adminSecret(): string | undefined {
  return env("ADMIN_SECRET");
}
