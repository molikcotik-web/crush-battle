export const PLATFORMS = ["tiktok", "shorts", "reels"] as const;
export const NICHES = [
  "gaming",
  "memes",
  "cars",
  "ai",
  "funny",
  "lifestyle",
  "crypto",
  "education",
  "other",
] as const;
export const LANGUAGES = ["en", "uk"] as const;
export const STYLES = [
  "faceless",
  "talking",
  "gameplay",
  "storytelling",
  "cinematic",
] as const;

export type Platform = (typeof PLATFORMS)[number];
export type Niche = (typeof NICHES)[number];
export type Language = (typeof LANGUAGES)[number];
export type Style = (typeof STYLES)[number];

export type VideoIdea = {
  title: string;
  hook: string;
  whatHappens: string;
  script: string;
  caption: string;
  hashtags: string[];
  length: string;
  cta: string;
  platform: Platform;
  niche: string;
  language: Language;
  style: Style;
};

export type InlineButton = {
  text: string;
  action: string;
};

export type ChatMessage = {
  id: string;
  role: "bot" | "user";
  text: string;
  idea?: VideoIdea;
  buttons?: InlineButton[][];
  createdAt: string;
};

export type WizardDraft = {
  platform?: Platform;
  niche?: string;
  language?: Language;
  style?: Style;
};

export type SessionState = {
  step:
    | "idle"
    | "gen_platform"
    | "gen_niche"
    | "gen_language"
    | "gen_style"
    | "awaiting_custom_niche";
  draft: WizardDraft;
  lastGenerationId?: number;
  messages: ChatMessage[];
};

export type PublicUser = {
  id: string;
  firstName: string;
  language: Language;
  niche: string | null;
  isPremium: boolean;
  isAdmin: boolean;
  remaining: number;
  dailyLimit: number;
  totalGenerations: number;
  savedCount: number;
};

export const DAILY_FREE_LIMIT = 3;
