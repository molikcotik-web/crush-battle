import { type ReactNode, useState } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "sonner";

export function AuthProvider({ children }: { children: ReactNode }) {
  const [client] = useState(
    () =>
      new QueryClient({
        defaultOptions: { queries: { refetchOnWindowFocus: false, retry: 1 } },
      }),
  );
  return (
    <QueryClientProvider client={client}>
      {children}
      <Toaster
        theme="dark"
        position="bottom-center"
        toastOptions={{
          className: "font-sans",
          style: {
            background: "#131316",
            color: "#f2efe8",
            border: "1px solid color-mix(in oklab, #f2efe8 12%, transparent)",
          },
        }}
      />
    </QueryClientProvider>
  );
}
