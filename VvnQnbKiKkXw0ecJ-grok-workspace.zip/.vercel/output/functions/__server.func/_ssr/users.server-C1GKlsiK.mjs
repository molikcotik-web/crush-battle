import { t as __exportAll } from "./rolldown-runtime-D7D4PA-g.mjs";
import { adminIds } from "./session.server-ByWawbEq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/users.server-C1GKlsiK.js
var _0002_video_ideas_default = "create table if not exists bot_users (\n  id text primary key,\n  telegram_id text unique,\n  username text,\n  first_name text,\n  language text not null default 'en',\n  niche text,\n  is_premium boolean not null default false,\n  is_admin boolean not null default false,\n  generations_today integer not null default 0,\n  generation_date date,\n  total_generations integer not null default 0,\n  last_active_at timestamptz not null default now(),\n  created_at timestamptz not null default now()\n);\n\ncreate index if not exists bot_users_telegram_id_idx on bot_users (telegram_id);\ncreate index if not exists bot_users_last_active_idx on bot_users (last_active_at);\n\ncreate table if not exists bot_sessions (\n  user_id text primary key references bot_users (id) on delete cascade,\n  state jsonb not null,\n  updated_at timestamptz not null default now()\n);\n\ncreate table if not exists generations (\n  id serial primary key,\n  user_id text not null references bot_users (id) on delete cascade,\n  platform text not null,\n  niche text not null,\n  language text not null,\n  style text not null,\n  ideas jsonb not null,\n  created_at timestamptz not null default now()\n);\n\ncreate index if not exists generations_user_id_idx on generations (user_id);\ncreate index if not exists generations_created_at_idx on generations (created_at);\n\ncreate table if not exists saved_ideas (\n  id serial primary key,\n  user_id text not null references bot_users (id) on delete cascade,\n  idea jsonb not null,\n  created_at timestamptz not null default now()\n);\n\ncreate index if not exists saved_ideas_user_id_idx on saved_ideas (user_id);\n\ncreate table if not exists daily_packs (\n  pack_date date not null,\n  language text not null,\n  ideas jsonb not null,\n  created_at timestamptz not null default now(),\n  primary key (pack_date, language)\n);\n\ncreate table if not exists trending_cache (\n  cache_date date not null,\n  language text not null,\n  ideas jsonb not null,\n  created_at timestamptz not null default now(),\n  primary key (cache_date, language)\n);\n\ncreate table if not exists broadcasts (\n  id serial primary key,\n  message text not null,\n  sent_count integer not null default 0,\n  created_at timestamptz not null default now()\n);\n\ncreate table if not exists telegram_updates (\n  update_id bigint primary key,\n  received_at timestamptz not null default now()\n);\n";
/**
* Migration bookkeeping shared by the two appliers — `scripts/migrate.mjs`
* (deploy, `readdir`) and `src/lib/db.ts` (PGLite preview, `import.meta.glob`).
*
* Applied files are keyed by BASENAME, so the same file applies once no matter
* which directory it is globbed from. That is what makes the auth schema safe to
* copy from `migrations/auth/` into `migrations/` when an app turns sign-in on:
* a database that already has `0001_auth.sql` will not re-run it.
*
* Neither applier descends into subdirectories, so `migrations/auth/*.sql` is
* out of scope for both until it is copied up.
*/
/**
* The `_migrations` key for a migration path (or bare filename).
* @param {string} path
* @returns {string}
*/
function migrationName(path) {
	return path.split("/").pop() ?? path;
}
/**
* @param {string} path
* @returns {boolean}
*/
function isMigrationFile(path) {
	return path.endsWith(".sql");
}
/**
* Migrations in `paths` that are not yet in `applied`, in apply order.
* Non-`.sql` entries (a `readdir` also yields `migrations/auth/`) are dropped.
* @param {Iterable<string>} paths
* @param {Iterable<string>} applied
* @returns {Array<{ name: string, path: string }>}
*/
function pendingMigrations(paths, applied) {
	const done = new Set(applied);
	return [...paths].filter(isMigrationFile).map((path) => ({
		name: migrationName(path),
		path
	})).sort((a, b) => a.name.localeCompare(b.name)).filter(({ name }) => !done.has(name));
}
var rawDatabaseUrl = typeof process !== "undefined" ? process.env.DATABASE_URL : void 0;
var databaseUrl = rawDatabaseUrl && rawDatabaseUrl.trim() ? rawDatabaseUrl : void 0;
/**
* Active backend: real **Neon** when `DATABASE_URL` is set (deployed / configured
* sandbox), otherwise a local embedded **PGLite** (Postgres compiled to WASM) so
* the app has a working database even with nothing configured — the live preview
* included. Swap in Neon later by just setting `DATABASE_URL`; no code changes.
*/
var dbSource = databaseUrl ? "neon" : "pglite";
/**
* Init state lives on globalThis as promises: dev HMR creates new instances of
* this module, and two instances racing module-level state would open a second
* pool or run two concurrent PGLite migration passes (whose duplicate
* `_migrations` insert rejects — and would get memoized, poisoning every later
* `getSql()`). A failed init clears its slot so the next call retries.
*/
var globalRef = globalThis;
/**
* Result-type parity: Postgres sends every value as text plus a type OID — the
* JS value is the DRIVER's parsing choice, and pg and PGLite disagree (pg:
* int8 -> string, date -> local-midnight Date; PGLite: int8 -> BigInt, which
* JSON.stringify rejects, date -> UTC Date). Normalize both so preview and
* production return identical, JSON-safe shapes:
*   int8/bigint (incl. count(*)) -> number (past 2^53 loses precision — cast
*                                   `::text` if you ever need huge integers)
*   date                         -> 'YYYY-MM-DD' string
*   interval                     -> Postgres interval text
* numeric already comes back as a string on both (arbitrary precision).
*/
var OID_INT8 = 20;
var OID_DATE = 1082;
var OID_INTERVAL = 1186;
var identity = (v) => v;
/** Wrap a query runner in the tagged-template + `.query()` `Sql` surface. */
function toSql(run) {
	const sql = (async (strings, ...values) => {
		let text = strings[0];
		for (let i = 0; i < values.length; i += 1) text += `$${i + 1}${strings[i + 1]}`;
		return run(text, values);
	});
	sql.query = (text, params = []) => run(text, params);
	return sql;
}
function createNeonSql() {
	globalRef.__pgSqlPromise__ ??= (async () => {
		const { Pool, types } = await import("../_libs/pg.mjs").then((n) => n.t);
		types.setTypeParser(OID_INT8, Number);
		types.setTypeParser(OID_DATE, identity);
		types.setTypeParser(OID_INTERVAL, identity);
		const pool = new Pool({ connectionString: databaseUrl });
		return toSql(async (text, params) => {
			return (await pool.query(text, params)).rows;
		});
	})().catch((err) => {
		globalRef.__pgSqlPromise__ = void 0;
		throw err;
	});
	return globalRef.__pgSqlPromise__;
}
async function createPgliteSql() {
	globalRef.__pgliteInstance__ ??= (async () => {
		const { PGlite } = await import("../_libs/electric-sql__pglite.mjs").then((n) => n.t);
		const pg = new PGlite({ parsers: {
			[OID_INT8]: Number,
			[OID_DATE]: identity,
			[OID_INTERVAL]: identity
		} });
		await pg.waitReady;
		await pg.exec("create table if not exists _migrations (name text primary key, applied_at timestamptz not null default now())");
		return pg;
	})().catch((err) => {
		globalRef.__pgliteInstance__ = void 0;
		throw err;
	});
	const pg = await globalRef.__pgliteInstance__;
	const migrate = async () => {
		const migrations = /* #__PURE__ */ Object.assign({ "/migrations/0002_video_ideas.sql": _0002_video_ideas_default });
		const done = (await pg.query("select name from _migrations")).rows.map((r) => r.name);
		for (const { name, path } of pendingMigrations(Object.keys(migrations), done)) await pg.transaction(async (tx) => {
			await tx.exec(migrations[path]);
			await tx.query("insert into _migrations (name) values ($1)", [name]);
		});
	};
	const pass = (globalRef.__pgliteMigrateChain__ ?? Promise.resolve()).catch(() => void 0).then(migrate);
	globalRef.__pgliteMigrateChain__ = pass;
	await pass;
	return toSql(async (text, params) => {
		return (await pg.query(text, params)).rows;
	});
}
var sqlPromise = null;
async function createSql() {
	if (typeof window !== "undefined") throw new Error("@/lib/db is server-only — call getSql() from a createServerFn handler or a server route loader, never from client code.");
	return dbSource === "neon" ? createNeonSql() : createPgliteSql();
}
/**
* Get the shared, **server-only** SQL client. Neon when `DATABASE_URL` is set,
* otherwise the local PGLite fallback. Memoized — safe to call per request.
*
* Schema comes from `migrations/*.sql`, auto-applied before the first query on
* both backends — define tables there, never inline in server functions.
*/
function getSql() {
	sqlPromise ??= createSql().catch((err) => {
		sqlPromise = null;
		throw err;
	});
	return sqlPromise;
}
/**
* Finish DB bootstrap before the server handles traffic.
*
* - **PGLite** (preview / no `DATABASE_URL`): open the in-memory DB and apply
*   `migrations/*.sql`. Idempotent — concurrent callers share one promise.
* - **Neon**: no-op (pool is created lazily on first query).
*
* Vite `configureServer` awaits this at dev startup; production imports of this
* module kick it off immediately (see bottom of file).
*/
function ensureDbReady() {
	if (dbSource !== "pglite") return Promise.resolve();
	return getSql().then(() => void 0);
}
var globalBoot = globalThis;
if (typeof window === "undefined" && dbSource === "pglite") globalBoot.__pgBootstrapPromise__ ??= ensureDbReady().catch((err) => {
	globalBoot.__pgBootstrapPromise__ = void 0;
	console.error("[db] PGLite bootstrap failed:", err);
	throw err;
});
var PLATFORMS = [
	"tiktok",
	"shorts",
	"reels"
];
var NICHES = [
	"gaming",
	"memes",
	"cars",
	"ai",
	"funny",
	"lifestyle",
	"crypto",
	"education",
	"other"
];
var LANGUAGES = ["en", "uk"];
var STYLES = [
	"faceless",
	"talking",
	"gameplay",
	"storytelling",
	"cinematic"
];
var users_server_exports = /* @__PURE__ */ __exportAll({
	consumeGeneration: () => consumeGeneration,
	getUser: () => getUser,
	loadSession: () => loadSession,
	remainingFor: () => remainingFor,
	saveSession: () => saveSession,
	setPremium: () => setPremium,
	setUserLanguage: () => setUserLanguage,
	setUserNiche: () => setUserNiche,
	toPublic: () => toPublic,
	upsertUser: () => upsertUser
});
function todayUtc() {
	return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
async function upsertUser(input) {
	const sql = await getSql();
	const isAdmin = input.telegramId ? adminIds().includes(input.telegramId) : false;
	await sql`
    insert into bot_users (id, telegram_id, username, first_name, language, is_admin)
    values (
      ${input.id},
      ${input.telegramId ?? null},
      ${input.username ?? null},
      ${input.firstName ?? "Creator"},
      ${input.language ?? "en"},
      ${isAdmin}
    )
    on conflict (id) do update set
      username = coalesce(excluded.username, bot_users.username),
      first_name = coalesce(excluded.first_name, bot_users.first_name),
      last_active_at = now(),
      is_admin = bot_users.is_admin or excluded.is_admin
  `;
	const user = (await sql`select * from bot_users where id = ${input.id}`)[0];
	if (!user) throw new Error("Failed to upsert user");
	return refreshDailyWindow(user);
}
async function refreshDailyWindow(user) {
	const today = todayUtc();
	if (user.generation_date === today) return user;
	return (await (await getSql())`
    update bot_users
    set generations_today = 0, generation_date = ${today}::date
    where id = ${user.id}
    returning *
  `)[0] ?? {
		...user,
		generations_today: 0,
		generation_date: today
	};
}
async function getUser(id) {
	const rows = await (await getSql())`select * from bot_users where id = ${id}`;
	if (!rows[0]) return null;
	return refreshDailyWindow(rows[0]);
}
function remainingFor(user) {
	if (user.is_premium) return 999;
	return Math.max(0, 3 - Number(user.generations_today));
}
async function toPublic(user) {
	const countRows = await (await getSql())`
    select count(*)::int as n from saved_ideas where user_id = ${user.id}
  `;
	return {
		id: user.id,
		firstName: user.first_name || "Creator",
		language: user.language === "uk" ? "uk" : "en",
		niche: user.niche,
		isPremium: Boolean(user.is_premium),
		isAdmin: Boolean(user.is_admin),
		remaining: remainingFor(user),
		dailyLimit: user.is_premium ? 0 : 3,
		totalGenerations: Number(user.total_generations),
		savedCount: Number(countRows[0]?.n ?? 0)
	};
}
async function consumeGeneration(userId) {
	const user = await getUser(userId);
	if (!user) return false;
	if (user.is_premium) {
		await (await getSql())`
      update bot_users
      set total_generations = total_generations + 1, last_active_at = now()
      where id = ${userId}
    `;
		return true;
	}
	if (remainingFor(user) <= 0) return false;
	return (await (await getSql())`
    update bot_users
    set generations_today = generations_today + 1,
        generation_date = ${todayUtc()}::date,
        total_generations = total_generations + 1,
        last_active_at = now()
    where id = ${userId}
      and (is_premium = true or generations_today < ${3})
    returning id
  `).length > 0;
}
async function setUserLanguage(userId, language) {
	await (await getSql())`update bot_users set language = ${language} where id = ${userId}`;
}
async function setUserNiche(userId, niche) {
	await (await getSql())`update bot_users set niche = ${niche} where id = ${userId}`;
}
async function setPremium(userId, value) {
	await (await getSql())`update bot_users set is_premium = ${value} where id = ${userId}`;
}
var emptyState = () => ({
	step: "idle",
	draft: {},
	messages: []
});
async function loadSession(userId) {
	const state = (await (await getSql())`
    select state from bot_sessions where user_id = ${userId}
  `)[0]?.state;
	const parsed = typeof state === "string" ? JSON.parse(state) : state;
	if (!parsed || typeof parsed !== "object") return emptyState();
	return {
		step: parsed.step ?? "idle",
		draft: parsed.draft ?? {},
		lastGenerationId: parsed.lastGenerationId,
		messages: Array.isArray(parsed.messages) ? parsed.messages : []
	};
}
async function saveSession(userId, state) {
	const sql = await getSql();
	const capped = {
		...state,
		messages: state.messages.slice(-80)
	};
	await sql`
    insert into bot_sessions (user_id, state, updated_at)
    values (${userId}, ${JSON.stringify(capped)}::jsonb, now())
    on conflict (user_id) do update set
      state = excluded.state,
      updated_at = now()
  `;
}
//#endregion
export { saveSession as a, setUserNiche as c, users_server_exports as d, LANGUAGES as f, getSql as g, STYLES as h, remainingFor as i, toPublic as l, PLATFORMS as m, getUser as n, setPremium as o, NICHES as p, loadSession as r, setUserLanguage as s, consumeGeneration as t, upsertUser as u };
