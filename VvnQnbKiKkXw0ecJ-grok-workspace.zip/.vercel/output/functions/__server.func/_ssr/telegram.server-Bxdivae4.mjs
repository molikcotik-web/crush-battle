import { adminIds, botToken, telegramUserId, webhookSecret } from "./session.server-ByWawbEq.mjs";
import { g as getSql, n as getUser, o as setPremium } from "./users.server-C1GKlsiK.mjs";
import { n as handleAction } from "./engine.server-x6ynx2FI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/telegram.server-Bxdivae4.js
var API = "https://api.telegram.org";
async function tg(method, body) {
	const token = botToken();
	if (!token) return false;
	try {
		return (await fetch(`${API}/bot${token}/${method}`, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(body)
		})).ok;
	} catch {
		return false;
	}
}
function markup(buttons) {
	if (!buttons?.length) return void 0;
	return { inline_keyboard: buttons.map((row) => row.map((b) => ({
		text: b.text,
		callback_data: b.action.slice(0, 64)
	}))) };
}
async function sendChat(chatId, messages) {
	for (const m of messages) await tg("sendMessage", {
		chat_id: chatId,
		text: m.text.slice(0, 3900),
		reply_markup: markup(m.buttons)
	});
}
function verifyTelegramSecret(header) {
	const expected = webhookSecret();
	if (!expected) return true;
	return header === expected;
}
async function processTelegramUpdate(update) {
	if (!(await (await getSql())`
    insert into telegram_updates (update_id)
    values (${update.update_id})
    on conflict (update_id) do nothing
    returning update_id
  `).length) return;
	if (update.callback_query) {
		const cq = update.callback_query;
		await tg("answerCallbackQuery", { callback_query_id: cq.id });
		const from = cq.from;
		const chatId = cq.message?.chat.id ?? from.id;
		const userId = telegramUserId(from.id);
		const data = cq.data || "menu";
		await sendChat(chatId, (await handleAction({
			userId,
			action: data,
			telegramId: String(from.id),
			username: from.username,
			firstName: from.first_name
		})).messages);
		return;
	}
	const message = update.message;
	if (!message?.from) return;
	const from = message.from;
	const text = (message.text ?? "").trim();
	const userId = telegramUserId(from.id);
	const chatId = message.chat.id;
	if (text.startsWith("/stats") || text.startsWith("/broadcast") || text.startsWith("/premium")) {
		const admins = adminIds();
		const user = await getUser(userId);
		if (!(admins.includes(String(from.id)) || Boolean(user?.is_admin))) {
			await tg("sendMessage", {
				chat_id: chatId,
				text: "Admin only."
			});
			return;
		}
		if (text.startsWith("/premium")) {
			const target = text.split(/\s+/)[1];
			if (!target) {
				await tg("sendMessage", {
					chat_id: chatId,
					text: "Usage: /premium <telegram_id>"
				});
				return;
			}
			const tid = target.startsWith("tg:") ? target : `tg:${target}`;
			await setPremium(tid, true);
			await tg("sendMessage", {
				chat_id: chatId,
				text: `Premium granted to ${tid}`
			});
			return;
		}
		if (text.startsWith("/broadcast")) {
			const payload = text.replace(/^\/broadcast(@\w+)?\s*/, "").trim();
			if (!payload) {
				await tg("sendMessage", {
					chat_id: chatId,
					text: "Usage: /broadcast <message>"
				});
				return;
			}
			const { broadcast } = await import("./admin.server-i9qqxr56.mjs");
			await tg("sendMessage", {
				chat_id: chatId,
				text: `Broadcast sent to ${await broadcast(payload)} users.`
			});
			return;
		}
		const { getAdminStats } = await import("./admin.server-i9qqxr56.mjs");
		const stats = await getAdminStats();
		await tg("sendMessage", {
			chat_id: chatId,
			text: [
				"Admin",
				`Users: ${stats.totalUsers}`,
				`Active (7d): ${stats.activeUsers}`,
				`Generated: ${stats.generatedIdeas}`,
				`New today: ${stats.newToday}`,
				`Premium: ${stats.premiumUsers}`
			].join("\n")
		});
		return;
	}
	const action = text.startsWith("/") ? text.split(/\s+/)[0].toLowerCase() : text;
	await sendChat(chatId, (await handleAction({
		userId,
		action,
		telegramId: String(from.id),
		username: from.username,
		firstName: from.first_name
	})).messages);
}
async function sendTelegramMessage(telegramId, text) {
	const numeric = telegramId.replace(/^tg:/, "");
	if (!/^\d+$/.test(numeric)) return false;
	return tg("sendMessage", {
		chat_id: Number(numeric),
		text: text.slice(0, 3900)
	});
}
async function setTelegramWebhook(publicUrl) {
	const token = botToken();
	if (!token) return {
		ok: false,
		error: "TELEGRAM_BOT_TOKEN is not set"
	};
	const secret = webhookSecret();
	const webhookUrl = `${publicUrl.replace(/\/$/, "")}/api/telegram/webhook`;
	try {
		const body = await (await fetch(`${API}/bot${token}/setWebhook`, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({
				url: webhookUrl,
				secret_token: secret,
				allowed_updates: ["message", "callback_query"],
				drop_pending_updates: false
			})
		})).json();
		if (!body.ok) return {
			ok: false,
			error: body.description ?? "setWebhook failed"
		};
		return { ok: true };
	} catch (err) {
		return {
			ok: false,
			error: err instanceof Error ? err.message : "setWebhook failed"
		};
	}
}
async function telegramStatus() {
	const token = botToken();
	if (!token) return {
		configured: false,
		username: null
	};
	try {
		const body = await (await fetch(`${API}/bot${token}/getMe`)).json();
		if (!body.ok) return {
			configured: true,
			username: null
		};
		return {
			configured: true,
			username: body.result?.username ?? null
		};
	} catch {
		return {
			configured: true,
			username: null
		};
	}
}
//#endregion
export { processTelegramUpdate, sendTelegramMessage, setTelegramWebhook, telegramStatus, verifyTelegramSecret };
