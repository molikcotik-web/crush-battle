import { o as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, i as useQueryClient, n as useQuery, o as require_react, t as useMutation } from "../_libs/react+tanstack__react-query.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as getAdminOverview, n as connectTelegram, o as sendBroadcast, s as setUserPremium, t as cn } from "./utils-BUyB7_Ht.mjs";
import { t as Button } from "./button-DlFrr1Mh.mjs";
import { d as ArrowLeft, l as Crown, n as Users, o as Sparkles, r as UserPlus, s as Radio, t as WalletCards } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as CartesianGrid, i as Area, n as YAxis, o as ResponsiveContainer, r as XAxis, s as Tooltip, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-DXlebg__.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("h-11 w-full rounded-md bg-elevated px-3 text-sm text-fg shadow-[var(--shadow-border)] placeholder:text-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/70", className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("min-h-28 w-full rounded-lg bg-elevated px-3 py-3 text-sm text-fg shadow-[var(--shadow-border)] placeholder:text-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/70", className),
		...props
	});
}
function AdminPage() {
	const [secret, setSecret] = (0, import_react.useState)("");
	const [draft, setDraft] = (0, import_react.useState)("");
	const qc = useQueryClient();
	const overview = useQuery({
		queryKey: ["admin", secret],
		queryFn: () => getAdminOverview({ data: { secret: secret || void 0 } })
	});
	const broadcast = useMutation({
		mutationFn: () => sendBroadcast({ data: {
			secret: secret || void 0,
			message: draft
		} }),
		onSuccess: (res) => {
			toast.success(`Broadcast queued for ${res.sent} users`);
			setDraft("");
			qc.invalidateQueries({ queryKey: ["admin"] });
		},
		onError: (err) => toast.error(err instanceof Error ? err.message : "Failed")
	});
	const premium = useMutation({
		mutationFn: (input) => setUserPremium({ data: {
			secret: secret || void 0,
			...input
		} }),
		onSuccess: () => void qc.invalidateQueries({ queryKey: ["admin"] }),
		onError: (err) => toast.error(err instanceof Error ? err.message : "Failed")
	});
	const connect = useMutation({
		mutationFn: () => connectTelegram({ data: { secret: secret || void 0 } }),
		onSuccess: (res) => {
			if (res.ok) toast.success("Webhook connected");
			else toast.error(res.error ?? "Could not connect");
		},
		onError: (err) => toast.error(err instanceof Error ? err.message : "Failed")
	});
	const data = overview.data;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-dvh bg-bg px-4 py-6 text-fg sm:px-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "inline-flex h-11 items-center gap-2 text-sm text-muted hover:text-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), "Studio"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "mt-6 flex flex-wrap items-end justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.2em] text-accent",
						children: "Operations"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-4xl font-semibold tracking-tight",
						children: "Admin"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex w-full max-w-sm items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "password",
							placeholder: "Admin secret (if set)",
							value: secret,
							onChange: (e) => setSecret(e.target.value),
							autoComplete: "off"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							onClick: () => void overview.refetch(),
							children: "Unlock"
						})]
					})]
				}),
				overview.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-10 text-muted",
					children: "Loading stats…"
				}) : null,
				data && data.ok === false ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-10 text-danger",
					children: data.error
				}) : null,
				data && data.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								icon: Users,
								label: "Total users",
								value: data.stats.totalUsers
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								icon: Sparkles,
								label: "Active (7d)",
								value: data.stats.activeUsers
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								icon: WalletCards,
								label: "Ideas generated",
								value: data.stats.generatedIdeas
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								icon: UserPlus,
								label: "New today",
								value: data.stats.newToday
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								icon: Crown,
								label: "Premium",
								value: data.stats.premiumUsers
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mt-8 rounded-2xl bg-surface p-5 shadow-[var(--shadow-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-lg font-semibold",
							children: "Generations · 14 days"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 h-56",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
								width: "100%",
								height: "100%",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
									data: data.stats.series,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
											id: "gen",
											x1: "0",
											y1: "0",
											x2: "0",
											y2: "1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
												offset: "0%",
												stopColor: "#7dceb0",
												stopOpacity: .35
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
												offset: "100%",
												stopColor: "#7dceb0",
												stopOpacity: 0
											})]
										}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
											stroke: "rgba(242,239,232,0.08)",
											vertical: false
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
											dataKey: "day",
											tickFormatter: (v) => v.slice(5),
											stroke: "#6e6c66",
											fontSize: 11,
											tickLine: false,
											axisLine: false
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
											stroke: "#6e6c66",
											fontSize: 11,
											allowDecimals: false,
											tickLine: false,
											axisLine: false,
											width: 28
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
											background: "#131316",
											border: "1px solid rgba(242,239,232,0.12)",
											borderRadius: 12,
											color: "#f2efe8"
										} }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
											type: "monotone",
											dataKey: "generations",
											stroke: "#7dceb0",
											fill: "url(#gen)",
											strokeWidth: 2
										})
									]
								})
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mt-8 grid gap-6 lg:grid-cols-[1.1fr_0.9fr]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl bg-surface p-5 shadow-[var(--shadow-border)]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-lg font-semibold",
									children: "Broadcast"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted",
									children: "Sends to every Telegram user. Web preview users are counted, not pinged."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									className: "mt-4",
									value: draft,
									onChange: (e) => setDraft(e.target.value),
									placeholder: "A short studio note…"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									className: "mt-3",
									disabled: !draft.trim() || broadcast.isPending,
									onClick: () => broadcast.mutate(),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "size-4" }), "Send broadcast"]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl bg-surface p-5 shadow-[var(--shadow-border)]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-lg font-semibold",
									children: "Telegram"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted",
									children: data.telegram.configured ? data.telegram.username ? `Connected as @${data.telegram.username}` : "Token present — webhook not confirmed" : "Set TELEGRAM_BOT_TOKEN to go live. The in-app chat already uses the same engine."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
									className: "mt-4 space-y-1 text-xs text-subtle",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "TELEGRAM_BOT_TOKEN" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "TELEGRAM_WEBHOOK_SECRET" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "TELEGRAM_ADMIN_IDS" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "ADMIN_SECRET · SESSION_SECRET" })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "secondary",
									className: "mt-4",
									disabled: !data.telegram.configured || connect.isPending,
									onClick: () => connect.mutate(),
									children: "Register webhook"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "mt-8 overflow-x-auto rounded-2xl bg-surface shadow-[var(--shadow-border)]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full min-w-[640px] text-left text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "text-xs uppercase tracking-wider text-subtle",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-border",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3 font-medium",
											children: "User"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3 font-medium",
											children: "Runs"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3 font-medium",
											children: "Last active"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3 font-medium",
											children: "Plan"
										})
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [data.users.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-border/60",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-4 py-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-medium",
											children: u.first_name || "Creator"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-xs text-subtle",
											children: u.username || u.id
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 tabular-nums",
										children: u.total_generations
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 text-muted",
										children: formatWhen(u.last_active_at)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "sm",
											variant: u.is_premium ? "primary" : "secondary",
											onClick: () => premium.mutate({
												userId: u.id,
												value: !u.is_premium
											}),
											children: u.is_premium ? "Premium" : "Free"
										})
									})
								]
							}, u.id)), data.users.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-8 text-muted",
								colSpan: 4,
								children: "No users yet. Open the studio chat to create the first one."
							}) }) : null] })]
						})
					})
				] }) : null
			]
		})
	});
}
function Stat({ icon: Icon, label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-surface px-4 py-4 shadow-[var(--shadow-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 text-accent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 font-display text-3xl font-semibold tabular-nums",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted",
				children: label
			})
		]
	});
}
function formatWhen(value) {
	const d = new Date(value);
	if (Number.isNaN(d.getTime())) return value;
	return d.toLocaleString(void 0, {
		month: "short",
		day: "numeric",
		hour: "2-digit",
		minute: "2-digit"
	});
}
//#endregion
export { AdminPage as component };
