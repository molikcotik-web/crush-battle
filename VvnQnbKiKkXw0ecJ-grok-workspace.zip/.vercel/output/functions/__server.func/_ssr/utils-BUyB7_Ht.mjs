import { i as getServerFnById, n as createServerFn, r as TSS_SERVER_FUNCTION } from "./ssr.mjs";
import { a as string, i as object, t as boolean } from "../_libs/zod.mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/utils-BUyB7_Ht.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var tokenField = string().max(800).optional();
var ensureWebSession = createServerFn({ method: "POST" }).validator(object({ token: tokenField })).handler(createSsrRpc("64d3e31f50b669f0a15f650b463c3a8c7914bab4f2f0b0885d95f4133a585e2d"));
var sendBotAction = createServerFn({ method: "POST" }).validator(object({
	token: string().min(8).max(800),
	action: string().min(1).max(200)
})).handler(createSsrRpc("22bbf575759ab93dba1c44fcd1ff32e7e2edd8048fb0a23376a19241a5beaee1"));
var getAdminOverview = createServerFn({ method: "POST" }).validator(object({ secret: string().max(200).optional() })).handler(createSsrRpc("01529992141f60dc348c74f480b393f20ce14f5b700b4b0d9894f3527461ebd2"));
var sendBroadcast = createServerFn({ method: "POST" }).validator(object({
	secret: string().max(200).optional(),
	message: string().min(1).max(1e3)
})).handler(createSsrRpc("4c7fcf3e3d7d8b95618d89e4f7fd1abc11bf4a404394cf4446ebf5b8f5cb4df8"));
var setUserPremium = createServerFn({ method: "POST" }).validator(object({
	secret: string().max(200).optional(),
	userId: string().min(1).max(80),
	value: boolean()
})).handler(createSsrRpc("79894466ab0eec7c16e9c663a9ab47013bb2ffb4e2986b40bef982ae218dc173"));
var connectTelegram = createServerFn({ method: "POST" }).validator(object({ secret: string().max(200).optional() })).handler(createSsrRpc("80deca073092d9394f3fcc08138080efaf0421b3fa371db9fec98ad0ba82bc95"));
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
//#endregion
export { sendBotAction as a, getAdminOverview as i, connectTelegram as n, sendBroadcast as o, ensureWebSession as r, setUserPremium as s, cn as t };
