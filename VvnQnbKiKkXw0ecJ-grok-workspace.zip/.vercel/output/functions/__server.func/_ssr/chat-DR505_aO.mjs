import { o as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { a as sendBotAction, r as ensureWebSession, t as cn } from "./utils-BUyB7_Ht.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { o as formatIdeaPlain, r as PLATFORM_META } from "./catalog-CIkgjc-F.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/chat-DR505_aO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TOKEN_KEY = "vib.session";
function useSessionToken() {
	const [token, setToken] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setToken(localStorage.getItem(TOKEN_KEY));
	}, []);
	const save = (next) => {
		localStorage.setItem(TOKEN_KEY, next);
		setToken(next);
	};
	return {
		token,
		save
	};
}
function TelegramChat({ compact = false }) {
	const { token, save } = useSessionToken();
	const [user, setUser] = (0, import_react.useState)(null);
	const [messages, setMessages] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [booting, setBooting] = (0, import_react.useState)(true);
	const scroller = (0, import_react.useRef)(null);
	const tokenRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		tokenRef.current = token;
	}, [token]);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		(async () => {
			try {
				const stored = localStorage.getItem(TOKEN_KEY) ?? void 0;
				const res = await ensureWebSession({ data: { token: stored } });
				if (cancelled) return;
				save(res.token);
				tokenRef.current = res.token;
				setUser(res.user);
				if (res.messages.length) setMessages(res.messages);
				else {
					const start = await sendBotAction({ data: {
						token: res.token,
						action: "/start"
					} });
					if (cancelled) return;
					setUser(start.user);
					setMessages(start.messages);
				}
			} catch (err) {
				toast.error(err instanceof Error ? err.message : "Could not start the bot");
			} finally {
				if (!cancelled) setBooting(false);
			}
		})();
		return () => {
			cancelled = true;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		const el = scroller.current;
		if (!el) return;
		el.scrollTo({
			top: el.scrollHeight,
			behavior: "smooth"
		});
	}, [messages, busy]);
	async function run(action, label) {
		const active = tokenRef.current;
		if (!active || busy) return;
		if (label) setMessages((m) => [...m, {
			id: crypto.randomUUID(),
			role: "user",
			text: label,
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		}]);
		setBusy(true);
		try {
			const res = await sendBotAction({ data: {
				token: active,
				action
			} });
			setUser(res.user);
			setMessages((m) => [...m, ...res.messages]);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Action failed");
		} finally {
			setBusy(false);
		}
	}
	async function copyIdea(idea) {
		await navigator.clipboard.writeText(formatIdeaPlain(idea));
		toast.success("Idea copied");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("tg-app flex h-full min-h-0 flex-col", compact && "text-sm"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex items-center gap-3 border-b border-[var(--tg-line)] bg-[var(--tg-header)] px-3 py-2.5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid size-10 place-items-center rounded-full bg-[var(--tg-mine)] text-sm font-semibold tracking-tight",
					children: "VI"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate font-medium leading-tight",
						children: "Video Ideas Bot"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-xs text-[var(--tg-meta)]",
						children: busy ? "typing…" : "online · short-form studio"
					})]
				}),
				user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full bg-[var(--tg-btn)] px-2.5 py-1 text-[11px] tabular-nums text-[var(--tg-btn-fg)]",
					children: user.isPremium ? "Premium" : `${user.remaining}/${user.dailyLimit}`
				}) : null
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			ref: scroller,
			className: "tg-scroll min-h-0 flex-1 space-y-3 overflow-y-auto px-3 py-4 pb-8",
			children: [
				booting ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex justify-center pt-10 text-sm text-[var(--tg-meta)]",
					children: "Opening chat…"
				}) : null,
				messages.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageBubble, {
					message: m,
					busy,
					onAction: run,
					onCopy: copyIdea
				}, m.id)),
				busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex justify-start",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-2xl rounded-bl-sm bg-[var(--tg-bubble)] px-3 py-2 text-[var(--tg-meta)]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "inline-block size-1.5 animate-pulse rounded-full bg-[var(--tg-accent)]" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "inline-block size-1.5 animate-pulse rounded-full bg-[var(--tg-accent)] [animation-delay:120ms]" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "inline-block size-1.5 animate-pulse rounded-full bg-[var(--tg-accent)] [animation-delay:240ms]" })
							]
						})
					})
				}) : null
			]
		})]
	});
}
function MessageBubble({ message, busy, onAction, onCopy }) {
	const mine = message.role === "user";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex", mine ? "justify-end" : "justify-start"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("max-w-[92%] rounded-2xl px-3 py-2 leading-relaxed", mine ? "rounded-br-sm bg-[var(--tg-mine)] text-[var(--tg-bubble-fg)]" : "rounded-bl-sm bg-[var(--tg-bubble)] text-[var(--tg-bubble-fg)]"),
			children: [message.idea ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdeaCard, {
				idea: message.idea,
				text: message.text,
				buttons: message.buttons,
				busy,
				onAction,
				onCopy
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "whitespace-pre-wrap",
				children: message.text
			}), message.buttons && !message.idea ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ButtonGrid, {
				buttons: message.buttons,
				busy,
				onAction
			}) : null]
		})
	});
}
function IdeaCard({ idea, text, buttons, busy, onAction, onCopy }) {
	const platform = PLATFORM_META[idea.platform]?.short ?? idea.platform;
	const saveBtn = buttons?.[0]?.find((b) => b.action.startsWith("save:"));
	const extra = buttons?.flat().filter((b) => !b.action.startsWith("save:") && !b.action.startsWith("copy:"));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-1.5 text-[10px] uppercase tracking-wider text-[var(--tg-meta)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: platform }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: idea.niche }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: idea.style }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: idea.length })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-medium leading-snug",
				children: idea.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Hook",
				value: idea.hook
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Happens",
				value: idea.whatHappens
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Script",
				value: idea.script
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Caption",
				value: idea.caption
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[12px] text-[var(--tg-accent)]",
				children: idea.hashtags.join(" ")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-[12px] text-[var(--tg-meta)]",
				children: ["CTA · ", idea.cta]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-1.5 pt-1",
				children: [
					saveBtn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TgButton, {
						disabled: busy,
						onClick: () => onAction(saveBtn.action, saveBtn.text),
						children: saveBtn.text
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TgButton, {
						disabled: busy,
						onClick: () => onCopy(idea),
						children: "Copy"
					}),
					extra?.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TgButton, {
						disabled: busy,
						onClick: () => onAction(b.action, b.text),
						children: b.text
					}, b.action))
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: text
			})
		]
	});
}
function Field({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-[10px] uppercase tracking-wider text-[var(--tg-meta)]",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "whitespace-pre-wrap text-[13px]",
		children: value
	})] });
}
function ButtonGrid({ buttons, busy, onAction }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-2 space-y-1.5",
		children: buttons.map((row, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap gap-1.5",
			children: row.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TgButton, {
				disabled: busy,
				onClick: () => onAction(b.action, b.text),
				children: b.text
			}, b.action))
		}, i))
	});
}
function TgButton({ children, onClick, disabled }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		disabled,
		onClick,
		className: "min-h-10 flex-1 rounded-md bg-[var(--tg-btn)] px-2.5 py-2 text-left text-[13px] font-medium text-[var(--tg-btn-fg)] transition-[transform,opacity] duration-150 ease-out hover:opacity-90 active:scale-[0.96] disabled:opacity-50",
		children
	});
}
//#endregion
export { TelegramChat as t };
