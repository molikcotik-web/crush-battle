import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as cn } from "./utils-BUyB7_Ht.mjs";
import { t as Button } from "./button-DlFrr1Mh.mjs";
import { a as TimerReset, c as LayoutDashboard, o as Sparkles, t as WalletCards, u as Clapperboard } from "../_libs/lucide-react.mjs";
import { t as TelegramChat } from "./chat-DR505_aO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-SNnhSeua.js
var import_jsx_runtime = require_jsx_runtime();
function PhoneFrame({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("relative mx-auto w-full max-w-[390px]", className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rounded-[2rem] bg-elevated p-2 shadow-[var(--shadow-border)]",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative overflow-hidden rounded-[1.55rem] bg-[var(--tg-bg,#0e1621)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pointer-events-none absolute inset-x-0 top-0 z-10 flex justify-center pt-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-5 w-24 rounded-full bg-bg/80" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-[min(720px,78dvh)] flex-col pt-5",
					children
				})]
			})
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-dvh overflow-hidden bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 film-grain opacity-40" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -left-24 top-[-8rem] h-[28rem] w-[28rem] rounded-full bg-accent/8 blur-3xl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto flex w-full max-w-6xl flex-col px-4 pb-16 pt-5 sm:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-9 place-items-center rounded-md bg-elevated shadow-[var(--shadow-border)]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clapperboard, { className: "size-4 text-accent" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-sm font-semibold tracking-tight",
								children: "Video Ideas Bot"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/bot",
								className: "hidden h-11 items-center rounded-md px-3 text-sm text-muted hover:text-fg sm:inline-flex",
								children: "Open chat"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/admin",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "secondary",
									size: "sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutDashboard, { className: "size-4" }), "Admin"]
								})
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mt-10 grid items-start gap-12 lg:mt-14 lg:grid-cols-[1.05fr_0.95fr]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "rise-in text-xs font-medium uppercase tracking-[0.22em] text-accent",
								children: "TikTok · Shorts · Reels"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "rise-in-2 mt-4 max-w-[14ch] font-display text-4xl font-semibold leading-[1.05] tracking-[-0.03em] sm:text-6xl",
								children: "Never run out of viral ideas."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "rise-in-3 mt-5 max-w-md text-base leading-relaxed text-muted sm:text-lg",
								children: "A Telegram studio that writes five complete concepts on command — hook, shot list, script, caption, hashtags, length and CTA. Three free generations a day. Premium never sleeps."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-8 flex flex-wrap items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#studio",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "lg",
										children: "Try it in the chat"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/admin",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "secondary",
										size: "lg",
										children: "Open admin"
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
								className: "mt-10 grid grid-cols-3 gap-3 max-w-lg",
								children: [
									["5", "ideas / run"],
									["3", "free daily"],
									["2", "languages"]
								].map(([n, l]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl bg-surface px-3 py-3 shadow-[var(--shadow-border)]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "font-display text-2xl font-semibold tabular-nums",
										children: n
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "mt-1 text-xs text-muted",
										children: l
									})]
								}, l))
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							id: "studio",
							className: "lg:pt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneFrame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TelegramChat, { compact: true }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-center text-xs text-subtle",
								children: "Live bot. Same engine the Telegram webhook uses."
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "mt-20 grid gap-4 sm:grid-cols-3",
						children: features.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "rounded-2xl bg-surface p-5 shadow-[var(--shadow-border)]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(f.icon, { className: "size-5 text-accent" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-4 font-display text-lg font-semibold",
									children: f.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-muted",
									children: f.body
								})
							]
						}, f.title))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mt-16 rounded-2xl bg-surface p-6 shadow-[var(--shadow-border)] sm:p-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl font-semibold",
							children: "How a generation works"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
							className: "mt-6 grid gap-6 sm:grid-cols-3",
							children: steps.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-display text-sm tabular-nums text-accent",
									children: ["0", i + 1]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-2 font-medium",
									children: s.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted",
									children: s.body
								})
							] }, s.title))
						})]
					})
				]
			})
		]
	});
}
var features = [
	{
		icon: Sparkles,
		title: "Production-ready packs",
		body: "Each idea ships with a 2–3 second hook, full short script, caption, 5–10 hashtags and a call to action."
	},
	{
		icon: TimerReset,
		title: "Daily limit, honest premium",
		body: "Three free generations reset at midnight UTC. Premium users generate without a cap. Saved ideas stay in your library."
	},
	{
		icon: WalletCards,
		title: "Telegram-native",
		body: "Inline menus, webhook, admin broadcast. Point TELEGRAM_BOT_TOKEN at this app and the same chat goes live on Telegram."
	}
];
var steps = [
	{
		title: "Brief",
		body: "Pick platform, niche, language and style — faceless, talking, gameplay, story or cinematic."
	},
	{
		title: "Write",
		body: "The studio returns five distinct concepts. Generate more on the same brief if the first batch is cold."
	},
	{
		title: "Ship",
		body: "Save keepers, copy the pack, film. Daily and trending menus refill without burning a credit."
	}
];
//#endregion
export { Home as component };
