//#region node_modules/.nitro/vite/services/ssr/assets/catalog-CIkgjc-F.js
var PLATFORM_META = {
	tiktok: {
		label: "TikTok",
		emoji: "🎵",
		short: "TikTok"
	},
	shorts: {
		label: "YouTube Shorts",
		emoji: "▶️",
		short: "Shorts"
	},
	reels: {
		label: "Instagram Reels",
		emoji: "📸",
		short: "Reels"
	}
};
var NICHE_META = {
	gaming: {
		label: "Gaming",
		emoji: "🎮",
		uk: "Ігри"
	},
	memes: {
		label: "Memes",
		emoji: "😂",
		uk: "Меми"
	},
	cars: {
		label: "Cars",
		emoji: "🚗",
		uk: "Авто"
	},
	ai: {
		label: "AI",
		emoji: "🤖",
		uk: "ШІ"
	},
	funny: {
		label: "Funny videos",
		emoji: "🤣",
		uk: "Приколи"
	},
	lifestyle: {
		label: "Lifestyle",
		emoji: "✨",
		uk: "Лайфстайл"
	},
	crypto: {
		label: "Crypto",
		emoji: "₿",
		uk: "Крипта"
	},
	education: {
		label: "Education",
		emoji: "📚",
		uk: "Освіта"
	},
	other: {
		label: "Other",
		emoji: "🎲",
		uk: "Інше"
	}
};
var STYLE_META = {
	faceless: {
		label: "Faceless",
		emoji: "🫥",
		uk: "Без обличчя"
	},
	talking: {
		label: "Talking",
		emoji: "🗣️",
		uk: "В кадрі"
	},
	gameplay: {
		label: "Gameplay",
		emoji: "🕹️",
		uk: "Геймплей"
	},
	storytelling: {
		label: "Storytelling",
		emoji: "📖",
		uk: "Історія"
	},
	cinematic: {
		label: "Cinematic",
		emoji: "🎥",
		uk: "Кінематограф"
	}
};
var LANG_META = {
	en: {
		label: "English",
		native: "English",
		flag: "🇬🇧"
	},
	uk: {
		label: "Ukrainian",
		native: "Українська",
		flag: "🇺🇦"
	}
};
function nicheLabel(niche, language) {
	const meta = NICHE_META[niche];
	if (!meta) return niche;
	return language === "uk" ? meta.uk : meta.label;
}
function styleLabel(style, language) {
	const meta = STYLE_META[style];
	return language === "uk" ? meta.uk : meta.label;
}
function formatIdeaPlain(idea) {
	const tags = idea.hashtags.map((t) => t.startsWith("#") ? t : `#${t}`).join(" ");
	return [
		idea.title,
		"",
		`Hook (0–3s): ${idea.hook}`,
		"",
		`What happens: ${idea.whatHappens}`,
		"",
		"Script:",
		idea.script,
		"",
		`Caption: ${idea.caption}`,
		"",
		tags,
		"",
		`Length: ${idea.length}`,
		`CTA: ${idea.cta}`
	].join("\n");
}
function formatIdeaHtml(idea, index) {
	const tags = idea.hashtags.map((t) => t.startsWith("#") ? t : `#${t}`).join(" ");
	return [
		`<b>${index}. ${escapeHtml(idea.title)}</b>`,
		"",
		`🪝 <b>Hook (0–3s)</b>\n${escapeHtml(idea.hook)}`,
		"",
		`🎬 <b>What happens</b>\n${escapeHtml(idea.whatHappens)}`,
		"",
		`📝 <b>Script</b>\n${escapeHtml(idea.script)}`,
		"",
		`💬 <b>Caption</b>\n${escapeHtml(idea.caption)}`,
		"",
		escapeHtml(tags),
		"",
		`⏱ ${escapeHtml(idea.length)}   ·   📣 ${escapeHtml(idea.cta)}`
	].join("\n");
}
function escapeHtml(value) {
	return value.replaceAll("&", "&").replaceAll("<", "<").replaceAll(">", ">");
}
//#endregion
export { formatIdeaHtml as a, styleLabel as c, STYLE_META as i, NICHE_META as n, formatIdeaPlain as o, PLATFORM_META as r, nicheLabel as s, LANG_META as t };
