import { adminSecret, isPreview } from "./session.server-ByWawbEq.mjs";
import { g as getSql } from "./users.server-C1GKlsiK.mjs";
import { sendTelegramMessage } from "./telegram.server-Bxdivae4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.server-i9qqxr56.js
function assertAdmin(secret) {
	const expected = adminSecret();
	if (!expected) return isPreview();
	return Boolean(secret) && secret === expected;
}
async function getAdminStats() {
	const sql = await getSql();
	const [total] = await sql`select count(*)::int as n from bot_users`;
	const [active] = await sql`
    select count(*)::int as n from bot_users
    where last_active_at > now() - interval '7 days'
  `;
	const generatedIdeas = (await sql`select ideas from generations`).reduce((sum, row) => {
		const ideas = row.ideas;
		return sum + (Array.isArray(ideas) ? ideas.length : 0);
	}, 0);
	const [newToday] = await sql`
    select count(*)::int as n from bot_users
    where created_at::date = (now() at time zone 'utc')::date
  `;
	const [premium] = await sql`
    select count(*)::int as n from bot_users where is_premium = true
  `;
	const [saved] = await sql`select count(*)::int as n from saved_ideas`;
	const series = await sql`
    select to_char(d::date, 'YYYY-MM-DD') as day,
           coalesce((
             select count(*)::int from generations g
             where g.created_at::date = d::date
           ), 0) as generations
    from generate_series(
      (now() at time zone 'utc')::date - 13,
      (now() at time zone 'utc')::date,
      interval '1 day'
    ) as d
  `;
	return {
		totalUsers: Number(total?.n ?? 0),
		activeUsers: Number(active?.n ?? 0),
		generatedIdeas,
		newToday: Number(newToday?.n ?? 0),
		premiumUsers: Number(premium?.n ?? 0),
		savedIdeas: Number(saved?.n ?? 0),
		series
	};
}
async function listUsers(limit = 40) {
	return (await getSql())`
    select id, first_name, username, is_premium, total_generations, last_active_at, created_at
    from bot_users
    order by last_active_at desc
    limit ${limit}
  `;
}
async function broadcast(message) {
	const sql = await getSql();
	const users = await sql`
    select id, telegram_id from bot_users
  `;
	let sent = 0;
	for (const u of users) if (u.telegram_id) {
		if (await sendTelegramMessage(u.telegram_id, message)) sent += 1;
	} else sent += 1;
	await sql`
    insert into broadcasts (message, sent_count)
    values (${message}, ${sent})
  `;
	return sent;
}
async function togglePremium(userId, value) {
	await (await getSql())`update bot_users set is_premium = ${value} where id = ${userId}`;
}
//#endregion
export { assertAdmin, broadcast, getAdminStats, listUsers, togglePremium };
