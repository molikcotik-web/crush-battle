import { n as createServerFn, r as TSS_SERVER_FUNCTION } from "./ssr.mjs";
import { a as string, i as object, t as boolean } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/fns-D2BDSoRr.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var tokenField = string().max(800).optional();
var ensureWebSession_createServerFn_handler = createServerRpc({
	id: "64d3e31f50b669f0a15f650b463c3a8c7914bab4f2f0b0885d95f4133a585e2d",
	name: "ensureWebSession",
	filename: "src/lib/bot/fns.ts"
}, (opts) => ensureWebSession.__executeServer(opts));
var ensureWebSession = createServerFn({ method: "POST" }).validator(object({ token: tokenField })).handler(ensureWebSession_createServerFn_handler, async ({ data }) => {
	const { verifySessionToken, issueSessionToken, newWebUserId } = await import("./session.server-ByWawbEq.mjs");
	const { upsertUser, loadSession, toPublic } = await import("./users.server-C1GKlsiK.mjs").then((n) => n.d);
	const userId = verifySessionToken(data.token) ?? newWebUserId();
	const user = await upsertUser({
		id: userId,
		firstName: "Creator"
	});
	const session = await loadSession(userId);
	return {
		token: issueSessionToken(userId),
		user: await toPublic(user),
		messages: session.messages
	};
});
var sendBotAction_createServerFn_handler = createServerRpc({
	id: "22bbf575759ab93dba1c44fcd1ff32e7e2edd8048fb0a23376a19241a5beaee1",
	name: "sendBotAction",
	filename: "src/lib/bot/fns.ts"
}, (opts) => sendBotAction.__executeServer(opts));
var sendBotAction = createServerFn({ method: "POST" }).validator(object({
	token: string().min(8).max(800),
	action: string().min(1).max(200)
})).handler(sendBotAction_createServerFn_handler, async ({ data }) => {
	const { verifySessionToken } = await import("./session.server-ByWawbEq.mjs");
	const userId = verifySessionToken(data.token);
	if (!userId) throw new Error("Session expired. Reload the page.");
	const { handleAction } = await import("./engine.server-x6ynx2FI.mjs").then((n) => n.t).then((n) => n.t);
	return handleAction({
		userId,
		action: data.action,
		firstName: "Creator"
	});
});
var getAdminOverview_createServerFn_handler = createServerRpc({
	id: "01529992141f60dc348c74f480b393f20ce14f5b700b4b0d9894f3527461ebd2",
	name: "getAdminOverview",
	filename: "src/lib/bot/fns.ts"
}, (opts) => getAdminOverview.__executeServer(opts));
var getAdminOverview = createServerFn({ method: "POST" }).validator(object({ secret: string().max(200).optional() })).handler(getAdminOverview_createServerFn_handler, async ({ data }) => {
	const { assertAdmin, getAdminStats, listUsers } = await import("./admin.server-i9qqxr56.mjs");
	const { telegramStatus } = await import("./telegram.server-Bxdivae4.mjs");
	const { adminSecret, isPreview } = await import("./session.server-ByWawbEq.mjs");
	if (!assertAdmin(data.secret)) return {
		ok: false,
		error: "Admin secret required"
	};
	const [stats, users, telegram] = await Promise.all([
		getAdminStats(),
		listUsers(),
		telegramStatus()
	]);
	return {
		ok: true,
		stats,
		users,
		telegram,
		needsSecret: Boolean(adminSecret()) && !isPreview()
	};
});
var sendBroadcast_createServerFn_handler = createServerRpc({
	id: "4c7fcf3e3d7d8b95618d89e4f7fd1abc11bf4a404394cf4446ebf5b8f5cb4df8",
	name: "sendBroadcast",
	filename: "src/lib/bot/fns.ts"
}, (opts) => sendBroadcast.__executeServer(opts));
var sendBroadcast = createServerFn({ method: "POST" }).validator(object({
	secret: string().max(200).optional(),
	message: string().min(1).max(1e3)
})).handler(sendBroadcast_createServerFn_handler, async ({ data }) => {
	const { assertAdmin, broadcast } = await import("./admin.server-i9qqxr56.mjs");
	if (!assertAdmin(data.secret)) throw new Error("Unauthorized");
	return { sent: await broadcast(data.message.trim()) };
});
var setUserPremium_createServerFn_handler = createServerRpc({
	id: "79894466ab0eec7c16e9c663a9ab47013bb2ffb4e2986b40bef982ae218dc173",
	name: "setUserPremium",
	filename: "src/lib/bot/fns.ts"
}, (opts) => setUserPremium.__executeServer(opts));
var setUserPremium = createServerFn({ method: "POST" }).validator(object({
	secret: string().max(200).optional(),
	userId: string().min(1).max(80),
	value: boolean()
})).handler(setUserPremium_createServerFn_handler, async ({ data }) => {
	const { assertAdmin, togglePremium } = await import("./admin.server-i9qqxr56.mjs");
	if (!assertAdmin(data.secret)) throw new Error("Unauthorized");
	await togglePremium(data.userId, data.value);
	return { ok: true };
});
var connectTelegram_createServerFn_handler = createServerRpc({
	id: "80deca073092d9394f3fcc08138080efaf0421b3fa371db9fec98ad0ba82bc95",
	name: "connectTelegram",
	filename: "src/lib/bot/fns.ts"
}, (opts) => connectTelegram.__executeServer(opts));
var connectTelegram = createServerFn({ method: "POST" }).validator(object({ secret: string().max(200).optional() })).handler(connectTelegram_createServerFn_handler, async ({ data }) => {
	const { assertAdmin } = await import("./admin.server-i9qqxr56.mjs");
	const { setTelegramWebhook } = await import("./telegram.server-Bxdivae4.mjs");
	const { getRequest } = await import("./ssr.mjs").then((n) => n.a).then((n) => n.t);
	if (!assertAdmin(data.secret)) throw new Error("Unauthorized");
	const request = getRequest();
	const url = new URL(request.url);
	const host = request.headers.get("x-forwarded-host") ?? url.host;
	return setTelegramWebhook(`${request.headers.get("x-forwarded-proto") ?? url.protocol.replace(":", "")}://${host}`);
});
//#endregion
export { connectTelegram_createServerFn_handler, ensureWebSession_createServerFn_handler, getAdminOverview_createServerFn_handler, sendBotAction_createServerFn_handler, sendBroadcast_createServerFn_handler, setUserPremium_createServerFn_handler };
