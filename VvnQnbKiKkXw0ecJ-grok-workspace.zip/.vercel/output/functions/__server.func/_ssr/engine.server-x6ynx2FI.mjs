import { r as __exportAll } from "../_runtime.mjs";
import { t as __exportAll$1 } from "./rolldown-runtime-D7D4PA-g.mjs";
import { isPreview } from "./session.server-ByWawbEq.mjs";
import { a as saveSession, c as setUserNiche, f as LANGUAGES, g as getSql, h as STYLES, i as remainingFor, l as toPublic, m as PLATFORMS, n as getUser, o as setPremium, p as NICHES, r as loadSession, s as setUserLanguage, t as consumeGeneration, u as upsertUser } from "./users.server-C1GKlsiK.mjs";
import { a as formatIdeaHtml, c as styleLabel, i as STYLE_META, n as NICHE_META, o as formatIdeaPlain, r as PLATFORM_META, s as nicheLabel, t as LANG_META } from "./catalog-CIkgjc-F.mjs";
import { randomUUID } from "node:crypto";
//#region node_modules/.nitro/vite/services/ssr/assets/engine.server-x6ynx2FI.js
var engine_server_x6ynx2FI_exports = /* @__PURE__ */ __exportAll({
	n: () => handleAction,
	t: () => engine_server_exports
});
var GLOBAL_AI_DAILY_CAP = 120;
function todayUtc() {
	return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
async function aiCallsToday() {
	const rows = await (await getSql())`
    select count(*)::int as n
    from generations
    where created_at::date = ${todayUtc()}::date
  `;
	return Number(rows[0]?.n ?? 0);
}
function extractJson(text) {
	const trimmed = text.trim();
	const raw = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/i)?.[1] ?? trimmed;
	const start = raw.indexOf("{");
	const end = raw.lastIndexOf("}");
	if (start < 0 || end <= start) throw new Error("No JSON object");
	return JSON.parse(raw.slice(start, end + 1));
}
function normalizeIdea(raw, input) {
	const title = str(raw.title);
	const hook = str(raw.hook);
	const whatHappens = str(raw.whatHappens ?? raw.what_happens);
	const script = str(raw.script);
	const caption = str(raw.caption);
	const cta = str(raw.cta);
	const length = str(raw.length) || (input.language === "uk" ? "15–25 с" : "15–25s");
	if (!title || !hook || !whatHappens || !script || !caption || !cta) return null;
	const tagsRaw = raw.hashtags;
	const hashtags = Array.isArray(tagsRaw) ? tagsRaw.map((t) => String(t).replace(/^#/, "").trim()).filter(Boolean).slice(0, 10) : [];
	if (hashtags.length < 4) hashtags.push(...defaultTags(input).slice(hashtags.length));
	return {
		title: title.slice(0, 120),
		hook: hook.slice(0, 240),
		whatHappens: whatHappens.slice(0, 500),
		script: script.slice(0, 1800),
		caption: caption.slice(0, 400),
		hashtags: hashtags.map((t) => t.startsWith("#") ? t : `#${t}`),
		length,
		cta: cta.slice(0, 180),
		platform: input.platform,
		niche: input.niche,
		language: input.language,
		style: input.style
	};
}
function str(v) {
	return typeof v === "string" ? v.trim() : "";
}
async function generateWithAi(input) {
	const apiKey = process.env.XAI_API_KEY?.trim();
	if (!apiKey) return null;
	if (await aiCallsToday() >= GLOBAL_AI_DAILY_CAP) return null;
	const platform = PLATFORM_META[input.platform].label;
	const langName = input.language === "uk" ? "Ukrainian" : "English";
	const avoid = input.avoidTitles?.length ? `Do not repeat these titles: ${input.avoidTitles.slice(0, 8).join(" | ")}` : "";
	const prompt = `You are a senior short-form producer who has shipped viral TikTok, YouTube Shorts, and Instagram Reels.

Create 5 UNIQUE video ideas for:
- Platform: ${platform}
- Niche: ${input.niche}
- Language: ${langName} (write EVERY field in ${langName})
- On-camera style: ${input.style}

Each idea must feel specific enough to film today. No generic "day in the life" filler. Include a pattern-interrupt hook in the first 2–3 seconds, a clear visual plan, and a full spoken/on-screen script for a 12–35s video.

${avoid}

Return ONLY JSON:
{
  "ideas": [
    {
      "title": "catchy title",
      "hook": "exact first 2-3 seconds of spoken or on-screen text",
      "whatHappens": "shot-by-shot what the viewer sees",
      "script": "full short script with [VISUAL] cues",
      "caption": "platform caption",
      "hashtags": ["tag", "tag"],
      "length": "15-25s",
      "cta": "end-screen call to action"
    }
  ]
}`;
	const controller = new AbortController();
	const timer = setTimeout(() => controller.abort(), 22e3);
	try {
		const res = await fetch("https://api.x.ai/v1/chat/completions", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			signal: controller.signal,
			body: JSON.stringify({
				model: "grok-4.5",
				temperature: .95,
				max_tokens: 2800,
				response_format: { type: "json_object" },
				messages: [{
					role: "system",
					content: "You write production-ready short-form video concepts. Never hedge. Never mention that you are an AI."
				}, {
					role: "user",
					content: prompt
				}]
			})
		});
		if (!res.ok) return null;
		const parsed = extractJson((await res.json()).choices?.[0]?.message?.content ?? "");
		if (!Array.isArray(parsed.ideas)) return null;
		const ideas = parsed.ideas.map((item) => item && typeof item === "object" ? normalizeIdea(item, input) : null).filter((x) => Boolean(x));
		return ideas.length >= 3 ? ideas.slice(0, 5) : null;
	} catch {
		return null;
	} finally {
		clearTimeout(timer);
	}
}
async function generateIdeas(input) {
	const ai = await generateWithAi(input);
	if (ai && ai.length) {
		while (ai.length < 5) {
			const next = fallbackIdeas({
				...input,
				salt: ai.length + 11
			}).find((e) => !ai.some((a) => a.title === e.title));
			if (!next) break;
			ai.push(next);
		}
		return ai.slice(0, 5);
	}
	return fallbackIdeas({
		...input,
		salt: Date.now() % 997
	});
}
async function cachedPack(kind, language) {
	const sql = await getSql();
	const today = todayUtc();
	if (kind === "daily") {
		const rows = await sql`
      select ideas from daily_packs
      where pack_date = ${today}::date and language = ${language}
    `;
		if (rows[0]?.ideas?.length) return rows[0].ideas;
	} else {
		const rows = await sql`
      select ideas from trending_cache
      where cache_date = ${today}::date and language = ${language}
    `;
		if (rows[0]?.ideas?.length) return rows[0].ideas;
	}
	const mix = [];
	const combos = kind === "daily" ? [
		{
			platform: "tiktok",
			niche: "memes",
			style: "faceless"
		},
		{
			platform: "shorts",
			niche: "education",
			style: "talking"
		},
		{
			platform: "reels",
			niche: "lifestyle",
			style: "cinematic"
		},
		{
			platform: "tiktok",
			niche: "ai",
			style: "storytelling"
		},
		{
			platform: "shorts",
			niche: "funny",
			style: "gameplay"
		}
	] : [
		{
			platform: "tiktok",
			niche: "gaming",
			style: "gameplay"
		},
		{
			platform: "reels",
			niche: "cars",
			style: "cinematic"
		},
		{
			platform: "shorts",
			niche: "crypto",
			style: "talking"
		},
		{
			platform: "tiktok",
			niche: "funny",
			style: "faceless"
		},
		{
			platform: "reels",
			niche: "ai",
			style: "storytelling"
		}
	];
	for (const combo of combos) {
		const batch = await generateIdeas({
			...combo,
			language
		});
		if (batch[0]) mix.push(batch[0]);
	}
	while (mix.length < 5) mix.push(...fallbackIdeas({
		platform: "tiktok",
		niche: "memes",
		language,
		style: "faceless",
		salt: mix.length + 3
	}).slice(0, 5 - mix.length));
	const ideas = mix.slice(0, 5);
	if (kind === "daily") await sql`
      insert into daily_packs (pack_date, language, ideas)
      values (${today}::date, ${language}, ${JSON.stringify(ideas)}::jsonb)
      on conflict (pack_date, language) do nothing
    `;
	else await sql`
      insert into trending_cache (cache_date, language, ideas)
      values (${today}::date, ${language}, ${JSON.stringify(ideas)}::jsonb)
      on conflict (cache_date, language) do nothing
    `;
	return ideas;
}
async function persistGeneration(input) {
	const rows = await (await getSql())`
    insert into generations (user_id, platform, niche, language, style, ideas)
    values (
      ${input.userId},
      ${input.platform},
      ${input.niche},
      ${input.language},
      ${input.style},
      ${JSON.stringify(input.ideas)}::jsonb
    )
    returning id
  `;
	return Number(rows[0]?.id ?? 0);
}
async function getGeneration(id, userId) {
	return (await (await getSql())`
    select ideas from generations where id = ${id} and user_id = ${userId}
  `)[0]?.ideas ?? null;
}
async function saveIdea(userId, idea) {
	const rows = await (await getSql())`
    insert into saved_ideas (user_id, idea)
    values (${userId}, ${JSON.stringify(idea)}::jsonb)
    returning id
  `;
	return Number(rows[0]?.id ?? 0);
}
async function listSaved(userId) {
	return (await (await getSql())`
    select id, idea, created_at from saved_ideas
    where user_id = ${userId}
    order by created_at desc
    limit 30
  `).map((r) => ({
		id: Number(r.id),
		idea: r.idea,
		createdAt: r.created_at
	}));
}
async function deleteSaved(userId, id) {
	return (await (await getSql())`
    delete from saved_ideas where id = ${id} and user_id = ${userId} returning id
  `).length > 0;
}
var ANGLES = {
	gaming: [
		{
			title: {
				en: "I used the worst loadout in ranked for 24 hours",
				uk: "Я грав добу в рейтинг з найгіршим лутом"
			},
			hook: {
				en: "Everyone said this gun is unusable. So I one-tricked it.",
				uk: "Усі казали, що ця зброя сміття. Тому я взяв тільки її."
			},
			happens: {
				en: "Cold open on a humiliating death, then a montage of adapting the 'trash' weapon until a clutch win. HUD + killfeed stay readable the whole time.",
				uk: "Старт з ганебної смерті, далі монтаж адаптації «сміттєвої» зброї до клатч-перемоги. HUD читається весь ролик."
			},
			script: {
				en: "[DEATH CAM] This is the gun nobody picks.\n[MONTAGE] First 10 games: I get farmed.\n[TEXT] Then I stopped aiming like it was a meta rifle.\n[CLUTCH] One tweak. One round. Chat goes silent.\n[END TEXT] Worst loadout. Best night.",
				uk: "[ДЕТКАМ] Цю зброю ніхто не бере.\n[МОНТАЖ] Перші 10 ігор мене носять.\n[ТЕКСТ] Потім я перестав цілитись як з мета-гвинтівки.\n[КЛАТЧ] Один твік. Один раунд. Чат замовк.\n[ФІНАЛ] Найгірший лут. Найкраща ніч."
			},
			caption: {
				en: "24 hours with the loadout everyone flames. The win at the end is not a joke.",
				uk: "Доба з лутом, який усі хейтять. Перемога в кінці — не прикол."
			},
			cta: {
				en: "Comment the worst gun in your game — I’ll run it next.",
				uk: "Напиши в коментарях найгіршу зброю — візьму її наступним."
			}
		},
		{
			title: {
				en: "Pros hide this setting and it is free elo",
				uk: "ПРО ховають це налаштування — це безкоштовне elo"
			},
			hook: {
				en: "If your aim feels cursed, you are missing one slider.",
				uk: "Якщо аім ніби проклятий — ти пропускаєш один повзунок."
			},
			happens: {
				en: "Split screen: default settings vs the hidden slider. Three before/after clips in the same range. End on the ranked badge ticking up.",
				uk: "Спліт-скрін: дефолт vs прихований повзунок. Три до/після на одному полігоні. Фініш — як росте ранг."
			},
			script: {
				en: "[SETTINGS MENU] Nobody talks about this because it looks boring.\n[BEFORE] Same flick. Same miss.\n[AFTER] Same flick. Target folds.\n[RANKED] That is not talent. That is contrast.\n[TEXT] Copy it. Close the video. Go queue.",
				uk: "[НАЛАШТУВАННЯ] Про це мовчать, бо виглядає нудно.\n[ДО] Той самий флік. Той самий промах.\n[ПІСЛЯ] Той самий флік. Таргет падає.\n[РЕЙТИНГ] Це не талант. Це контраст.\n[ТЕКСТ] Скопіюй. Закрий відео. Йди в чергу."
			},
			caption: {
				en: "One slider. Instantly cleaner aim. Save this before they patch the default.",
				uk: "Один повзунок. Аім одразу чистіший. Збережи, поки не змінять дефолт."
			},
			cta: {
				en: "Follow for the rest of the 'boring' settings that actually win games.",
				uk: "Підпишись — розберу інші «нудні» налаштування, які виграють ігри."
			}
		},
		{
			title: {
				en: "I let my chat pick every ability. Chaos speedrun",
				uk: "Чат обирав усі здібності. Спідран хаосу"
			},
			hook: {
				en: "Chat, if this build works I owe you an apology.",
				uk: "Чате, якщо цей білд зайде — я винен вибачення."
			},
			happens: {
				en: "Live chat votes flash on screen between fights. Each bad pick gets a comic sting. Final boss dies to the meme combo.",
				uk: "Голосування чату на екрані між боями. Кожен поганий пік — комічний звук. Фінальний бос падає від мем-комбо."
			},
			script: {
				en: "[POLL] First ability: the one with a 4% pick rate.\n[WIPE] Okay. That is on you.\n[POLL 2] Double down? Chat says double down.\n[BOSS] Wait. Wait. It chains.\n[WIN SCREEN] Never doubt the gremlins.",
				uk: "[ОПИТУВАННЯ] Перша здібність: пік 4%.\n[ВАЙП] Окей. Це на вас.\n[ОПИТУВАННЯ 2] Подвоюємо? Чат каже подвоюємо.\n[БОС] Зачекай. Воно лінкується.\n[ПЕРЕМОГА] Ніколи не сумнівайся в гремлінах."
			},
			caption: {
				en: "Chat built this. I just held the buttons. Insane luck or secret sauce?",
				uk: "Це зібрав чат. Я лише тицяв кнопки. Удача чи секрет?"
			},
			cta: {
				en: "Join the next vote — link in bio.",
				uk: "Приходь на наступне голосування — лінк у шапці."
			}
		}
	],
	memes: [{
		title: {
			en: "POV: you explain the meme to someone three years late",
			uk: "ПОВ: пояснюєш мем людині з запізненням на три роки"
		},
		hook: {
			en: "They just asked 'who is Skibidi'. Stay with me.",
			uk: "Вони щойно спитали «хто такий Скібіді». Залишайся."
		},
		happens: {
			en: "Rapid-fire visual glossary: original clip, mutation, corporate copy, grandpa sticker. Punchline is the viewer realizing they are the grandpa.",
			uk: "Швидкий словник: оригінал, мутація, корпоративна копія, стікер від дідуся. Панч — глядач розуміє, що він і є дідусь."
		},
		script: {
			en: "[ZOOM] This started as a joke in a basement.\n[CUT] Then a brand used it in an ad.\n[CUT] Then your uncle sent it with a thumbs-up emoji.\n[HOLD] If you needed this video, it is already over for you.\n[TEXT] Share it anyway.",
			uk: "[ЗУМ] Це почалось як жарт у підвалі.\n[КАДР] Потім бренд засунув це в рекламу.\n[КАДР] Потім дядько надіслав зі стікером «палець вгору».\n[ПАУЗА] Якщо тобі потрібне це відео — для тебе вже пізно.\n[ТЕКСТ] Але все одно поділись."
		},
		caption: {
			en: "A public service announcement for people who still say 'it's giving' unironically.",
			uk: "Оголошення для тих, хто досі серйозно каже «it's giving»."
		},
		cta: {
			en: "Duet this with the meme you still don't understand.",
			uk: "Зроби дует із мемом, який досі не розумієш."
		}
	}, {
		title: {
			en: "I ranked 2026's dead memes from respectfully retired to criminal",
			uk: "Зарейтив мертві меми 2026: від почесної пенсії до злочину"
		},
		hook: {
			en: "If you still post this one, I am calling your manager.",
			uk: "Якщо ти досі постиш оце — я дзвоню твоєму менеджеру."
		},
		happens: {
			en: "Tier list on screen. Each meme gets a 1-second example then a gavel slam. Final S-tier is an unexpected wholesome format.",
			uk: "Тір-ліст на екрані. Кожен мем — секундний приклад і удар молотка. Фінальний S-тір — несподівано теплий формат."
		},
		script: {
			en: "[TIER LIST] D-tier: the audio everyone is tired of.\n[SLAM] C-tier: the face. You know the face.\n[SLAM] B-tier: still funny if your timing is elite.\n[S] This one? Untouchable. Protect it.\n[TEXT] Fight me in the comments.",
			uk: "[ТІР-ЛІСТ] D: звук, від якого всі втомились.\n[УДАР] C: оце лице. Ти знаєш яке.\n[УДАР] B: ще смішно, якщо таймінг божий.\n[S] А цей? Не чіпати. Охороняти.\n[ТЕКСТ] Давай у коментарях."
		},
		caption: {
			en: "Dead meme autopsy. No notes. Lots of violence (gavel only).",
			uk: "Аутопсія мертвих мемів. Без купюр. Насильство тільки молотком."
		},
		cta: {
			en: "Drop the meme I missed — I'll add a part 2.",
			uk: "Кинь мем, який я пропустив — буде частина 2."
		}
	}],
	cars: [{
		title: {
			en: "This $800 modification makes a civic sound illegal",
			uk: "Модифікація за $800 змушує Civic звучати незаконно"
		},
		hook: {
			en: "Stock Civic. Watch the pedestrian turn around.",
			uk: "Сток Civic. Дивись, як пішохід обертається."
		},
		happens: {
			en: "Before/after pull-aways from the same light. Mic on the exhaust, then cabin. Quick parts-on-the-floor shot. Night city b-roll.",
			uk: "До/після старту з одного світлофора. Мікрофон на вихлопі, потім у салоні. Кадр запчастин на підлозі. Нічний сіті-ролл."
		},
		script: {
			en: "[STOCK] This is a grocery getter.\n[INSTALL] One resonator. Two gaskets. An hour.\n[PULL AWAY] That is not a Civic anymore.\n[CABIN] And it is still daily-able.\n[TEXT] Link to the exact parts — no mystery boxes.",
			uk: "[СТОК] Це машина до магазину.\n[ВСТАНОВЛЕННЯ] Один резонатор. Дві прокладки. Година.\n[СТАРТ] Це вже не Civic.\n[САЛОН] І на ній досі можна щодня.\n[ТЕКСТ] Посилання на точні деталі — без коробок-сюрпризів."
		},
		caption: {
			en: "Night pull-aways only. Exact parts list in the first comment.",
			uk: "Тільки нічні старти. Точний список деталей у першому коментарі."
		},
		cta: {
			en: "Save this if your civic is still whispering.",
			uk: "Збережи, якщо твій Civic досі шепоче."
		}
	}, {
		title: {
			en: "I let GPS pick a 40-minute joyride. It chose violence",
			uk: "Віддав GPS кермо на 40 хвилин. Він обрав насильство"
		},
		hook: {
			en: "Random destination. No highway. If I stall, the video dies.",
			uk: "Випадкова точка. Без траси. Якщо заглухну — відео помре."
		},
		happens: {
			en: "Dash + cabin cam. Tight hairpins, a surprise dirt cutoff, a fuel-light scare. Ends on a view the driver did not know existed in their city.",
			uk: "Реєстратор + салон. Тісні шпильки, раптовий ґрунтовий зріз, лампочка пального. Фініш — краєвид, про який водій у своєму місті не знав."
		},
		script: {
			en: "[SPIN THE WHEEL] GPS, do your worst.\n[CORNER] This is not a road. This is a suggestion.\n[FUEL LIGHT] Comedy option: ignore it.\n[VISTA] Okay. The algorithm can stay.\n[TEXT] Try this in your city — tag me.",
			uk: "[КОЛЕСО] GPS, зроби гірше.\n[ПОВОРОТ] Це не дорога. Це натяк.\n[ПАЛИВО] Комедійний варіант: ігнорувати.\n[КРАЄВИД] Окей. Алгоритм може жити.\n[ТЕКСТ] Спробуй у своєму місті — познач мене."
		},
		caption: {
			en: "No route planning. Just a tank of gas and a terrible idea.",
			uk: "Без маршруту. Бак бензину і погана ідея."
		},
		cta: {
			en: "Follow for part 2: night version.",
			uk: "Підпишись на частину 2: нічна версія."
		}
	}],
	ai: [{
		title: {
			en: "I let AI run my morning for 12 hours. It got weird at 9:14",
			uk: "Віддав ранок ШІ на 12 годин. О 9:14 стало дивно"
		},
		hook: {
			en: "The assistant booked a meeting with me. I did not ask.",
			uk: "Асистент записав мене на зустріч зі мною. Я не просив."
		},
		happens: {
			en: "Screen recordings of prompts, calendar popups, a generated grocery list that includes 'existential buffer'. Cut to the human staring at a smoothie the AI invented.",
			uk: "Запис екрана з промптами, попапи календаря, список покупок із пунктом «екзистенційний буфер». Кадр людини, що дивиться на смузі, який вигадав ШІ."
		},
		script: {
			en: "[6:00] Wake-up prompt: 'optimize me'.\n[7:10] It cancelled coffee. Cited cortisol.\n[9:14] A calendar event: 'Reconcile with your unfinished drafts'.\n[SMOOTHIE] I drank it. I am not proud.\n[TEXT] Would you last until lunch?",
			uk: "[6:00] Промпт підйому: «оптимізуй мене».\n[7:10] Воно скасувало каву. Посилалось на кортизол.\n[9:14] Подія: «Помирись із незакінченими чернетками».\n[СМУЗІ] Я випив. Не пишаюсь.\n[ТЕКСТ] Ти дотягнеш до обіду?"
		},
		caption: {
			en: "AI morning experiment. The grocery list is in the comments for the brave.",
			uk: "Ранковий експеримент зі ШІ. Список покупок у коментарях — для сміливих."
		},
		cta: {
			en: "Comment 'BOT' if your assistant already runs you.",
			uk: "Напиши «БОТ», якщо асистент уже керує тобою."
		}
	}, {
		title: {
			en: "This prompt turns a messy voice note into a week of content",
			uk: "Цей промпт з голосового робить тиждень контенту"
		},
		hook: {
			en: "Stop typing captions. Talk for 40 seconds instead.",
			uk: "Припини друкувати описи. Поговори 40 секунд."
		},
		happens: {
			en: "Show the raw voice-note waveform, paste the prompt, then a cascade of 7 posts appearing. Highlight the hook line it invented.",
			uk: "Сира хвиля голосового, вставка промпта, каскад із 7 постів. Підсвітити гачок, який він вигадав."
		},
		script: {
			en: "[VOICE NOTE] I ramble about a customer complaint.\n[PROMPT] One block. Copy it once.\n[OUTPUT] 7 posts. 3 hooks. A carousel outline.\n[CIRCLE] This line? I would have never written it.\n[TEXT] Prompt in the first comment. Steal it.",
			uk: "[ГОЛОСОВЕ] Я бурчу про скаргу клієнта.\n[ПРОМПТ] Один блок. Копіюєш раз.\n[РЕЗУЛЬТАТ] 7 постів. 3 гачки. Каркас каруселі.\n[КОЛО] Цей рядок я б ніколи не написав.\n[ТЕКСТ] Промпт у першому коментарі. Бери."
		},
		caption: {
			en: "One voice note → a week of posts. Prompt is free, your excuses are not.",
			uk: "Одне голосове → тиждень постів. Промпт безкоштовний, виправдання — ні."
		},
		cta: {
			en: "Follow — tomorrow I drop the image-prompt version.",
			uk: "Підпишись — завтра скину версію для картинок."
		}
	}],
	funny: [{
		title: {
			en: "Things my brain says vs what I actually text back",
			uk: "Що каже мозок vs що я насправді відповідаю"
		},
		hook: {
			en: "Incoming text: 'we need to talk'. My soul leaves.",
			uk: "Вхідне: «треба поговорити». Душа виходить з чату."
		},
		happens: {
			en: "Split: left side is theatrical inner monologue, right side is the world's driest reply. Three escalating texts. Last one is 'ok'.",
			uk: "Спліт: ліворуч театральний внутрішній монолог, праворуч найсухіша відповідь. Три ескалації. Остання — «ок»."
		},
		script: {
			en: "[PHONE] 'we need to talk'\n[BRAIN] Update your will. Delete the camera roll. Move countries.\n[THUMBS] 'hey what's up?'\n[PHONE] 'are you free thursday'\n[BRAIN] Marriage or firing squad.\n[SEND] 'ok'",
			uk: "[ТЕЛЕФОН] «треба поговорити»\n[МОЗОК] Онови заповіт. Видали галерею. Зміни країну.\n[ПАЛЬЦІ] «привіт, що сталось?»\n[ТЕЛЕФОН] «ти вільний у четвер»\n[МОЗОК] Шлюб або розстріл.\n[НАДІСЛАТИ] «ок»"
		},
		caption: {
			en: "Emotionally stable? Absolutely not. Replied in 0.4 seconds though.",
			uk: "Емоційно стабільний? Абсолютно ні. Але відповів за 0.4 секунди."
		},
		cta: {
			en: "Duet with your actual reply history.",
			uk: "Зроби дует зі своєю реальною історією чату."
		}
	}, {
		title: {
			en: "I followed my cat's routine for a day and clocked out at 10:12",
			uk: "Повторював режим кота і закрив зміну о 10:12"
		},
		hook: {
			en: "The cat has four jobs. All of them are lying down.",
			uk: "У кота чотири роботи. Усі — лежати."
		},
		happens: {
			en: "Human mirrors the cat: sunbeam, aggressive grooming, judging a laptop, sudden sprint, immediate nap. Timestamp overlays.",
			uk: "Людина копіює кота: сонячна пляма, агресивний грумінг, засудження ноутбука, раптовий спринт, сон. Таймкоди."
		},
		script: {
			en: "[6:40] Sunbeam shift. Union mandated.\n[8:00] Stare at the human who works. Unpaid internship.\n[10:12] Zoomies. Then nothing. Clock out.\n[TEXT] CEO energy. Zero emails.\n[END] Subscribe if your manager is also a cat.",
			uk: "[6:40] Зміна в сонячній плямі. За колективним.\n[8:00] Дивитись на людину, що працює. Неоплачувана практика.\n[10:12] Зуміс. Потім нічого. Зміна закрита.\n[ТЕКСТ] Енергія CEO. Нуль листів.\n[КІНЕЦЬ] Підпишись, якщо твій керівник теж кіт."
		},
		caption: {
			en: "A scientifically rigorous study with a sample size of one loaf.",
			uk: "Науково суворе дослідження на вибірці з одного хлібчика."
		},
		cta: {
			en: "Tag the coworker who already lives like this.",
			uk: "Познач колегу, який уже так живе."
		}
	}],
	lifestyle: [{
		title: {
			en: "My 20-minute reset after a ruined day (no 5am club)",
			uk: "Мої 20 хвилин після зіпсованого дня (без клубу 5 ранку)"
		},
		hook: {
			en: "The day already lost. This is how I steal the evening back.",
			uk: "День уже програний. Ось як я краду вечір назад."
		},
		happens: {
			en: "Soft lamp, phone in another room, one song, cold water on wrists, a three-item list on paper. No talking until the last line.",
			uk: "М'яка лампа, телефон в іншій кімнаті, один трек, холодна вода на зап'ястя, три пункти на папері. Без слів до останнього рядка."
		},
		script: {
			en: "[DOOR] Shoes off like you mean it.\n[PHONE] Not on silent. In the other room.\n[WATER] Wrists. 20 seconds. Nervous system is cheap to bribe.\n[PAPER] Three things only. Tomorrow can be smaller.\n[TEXT] You do not need a new personality. You need 20 minutes.",
			uk: "[ДВЕРІ] Взуття геть — як слід.\n[ТЕЛЕФОН] Не без звуку. В іншій кімнаті.\n[ВОДА] Зап'ястя. 20 секунд. Нервову систему дешево підкупити.\n[ПАПІР] Лише три пункти. Завтра може бути меншим.\n[ТЕКСТ] Тобі не потрібна нова особистість. Тобі треба 20 хвилин."
		},
		caption: {
			en: "A reset for people who will never be 5am influencers.",
			uk: "Перезапуск для тих, хто ніколи не стане інфлюенсером п'ятої ранку."
		},
		cta: {
			en: "Save this for the next ugly day.",
			uk: "Збережи на наступний поганий день."
		}
	}, {
		title: {
			en: "Pack a weekend bag like you might not come back (in a cute way)",
			uk: "Збери сумку на вікенд так, ніби можеш не повернутись (мило)"
		},
		hook: {
			en: "If it does not earn a seat, it stays on the bed.",
			uk: "Якщо річ не заслужила місце — хай лежить на ліжку."
		},
		happens: {
			en: "Flat-lay packing, ruthless edits, one 'maybe' item that gets cut, a final zip. Train window b-roll.",
			uk: "Розкладка, жорсткі скорочення, одна річ «може» яку викидають, фінальна блискавка. Б-ролл з вікна потяга."
		},
		script: {
			en: "[BED] Everything you 'might' need is a liar.\n[FOLD] Two outfits that can swap parts.\n[CUT] The extra shoes. You are not a showroom.\n[ZIP] Now you can leave in 90 seconds.\n[WINDOW] That is the whole point.",
			uk: "[ЛІЖКО] Усе, що «може знадобитись» — брехня.\n[СКЛАСТИ] Два образи, що діляться деталями.\n[ВИКИНУТИ] Зайве взуття. Ти не шоурум.\n[БЛИСКАВКА] Тепер можна вийти за 90 секунд.\n[ВІКНО] В цьому і сенс."
		},
		caption: {
			en: "One bag. No spirals. The maybe pile is a personality test.",
			uk: "Одна сумка. Без спіралей. Купа «може» — це тест особистості."
		},
		cta: {
			en: "Follow for the 10-item capsule I actually travel with.",
			uk: "Підпишись — покажу капсулу з 10 речей, з якою їжджу."
		}
	}],
	crypto: [{
		title: {
			en: "I tracked every 'trust me bro' call for 30 days. The chart is rude",
			uk: "Місяць записував усі 'trust me bro'. Графік неввічливий"
		},
		hook: {
			en: "If you muted this audio, you already know how it ends.",
			uk: "Якщо вимкнув звук — ти вже знаєш фінал."
		},
		happens: {
			en: "Screenshots of Telegram calls timestamped, then the same tickers 7 days later in red. One surprising winner. A simple rule written on screen.",
			uk: "Скріни телеграм-коллів з датою, ті самі тікери за 7 днів у мінусі. Один несподіваний плюс. Просте правило на екрані."
		},
		script: {
			en: "[CALL #1] 'This is the floor.' It was not the floor.\n[CALL #4] 'Whales are accumulating.' The whale was exit liquidity.\n[WINNER] One ticker actually printed. It was the boring one.\n[RULE] If it needs a rocket emoji, wait.\n[TEXT] Not financial advice. It is anti-advice.",
			uk: "[КОЛ #1] «Це дно». Це не було дно.\n[КОЛ #4] «Кити накопичують». Кит був екіт-ліквідністю.\n[ПЕРЕМОЖЕЦЬ] Один тікер справді виріс. Нудний.\n[ПРАВИЛО] Якщо потрібна ракета в емодзі — чекай.\n[ТЕКСТ] Не фінпорада. Антипорада."
		},
		caption: {
			en: "30 days of calls vs reality. The only green candle was patience.",
			uk: "30 днів коллів проти реальності. Єдина зелена свічка — терпіння."
		},
		cta: {
			en: "Follow for the spreadsheet method, not the hopium.",
			uk: "Підпишись — покажу метод таблиці, не хопіум."
		}
	}, {
		title: {
			en: "Explain on-chain like I am your slightly impatient cousin",
			uk: "Пояснюю ончейн, ніби ти мій трохи нетерплячий кузен"
		},
		hook: {
			en: "Wallets are just receipts that cannot lie. That is the whole class.",
			uk: "Гаманці — це чеки, які не вміють брехати. Це весь урок."
		},
		happens: {
			en: "White-on-black diagrams, one real transaction highlighted, a 'smart money' wallet vs a 'just got paid' wallet. No token names that look like shills.",
			uk: "Схеми білим по чорному, одна реальна транзакція, гаманець «розумних грошей» vs «щойно зарплата». Без шил-токенів."
		},
		script: {
			en: "[BOARD] Price is a rumor. Transfers are minutes of a meeting.\n[TX] This wallet bought, then sent to exchanges. That is not 'diamond hands'.\n[TX 2] This one is still sitting. Boring. Powerful.\n[TEXT] Follow the receipts, not the spaces.\n[END] Class dismissed in 20 seconds.",
			uk: "[ДОШКА] Ціна — чутка. Перекази — протокол зборів.\n[ТХ] Цей гаманець купив і одразу на біржу. Це не diamond hands.\n[ТХ 2] Цей досі сидить. Нудно. Сильно.\n[ТЕКСТ] Читай чеки, не чати.\n[КІНЕЦЬ] Урок за 20 секунд."
		},
		caption: {
			en: "On-chain without the guru voice. Save this before the next candle.",
			uk: "Ончейн без голосу гуру. Збережи до наступної свічки."
		},
		cta: {
			en: "Comment a ticker and I’ll read the receipts next.",
			uk: "Напиши тікер — наступним прочитаю чеки."
		}
	}],
	education: [{
		title: {
			en: "The 12-minute study block that beats a 3-hour fake session",
			uk: "12 хвилин навчання, що б'ють 3 години фейкової сесії"
		},
		hook: {
			en: "If you 'study' with 14 tabs, you are decorating anxiety.",
			uk: "Якщо вчишся з 14 вкладками — ти прикрашаєш тривогу."
		},
		happens: {
			en: "Timer, one question on paper, phone in a bowl of rice (joke then real drawer), a teach-back to camera in 30 seconds.",
			uk: "Таймер, одне питання на папері, телефон у мисці рису (жарт), потім у шухляді, 30-секундний переказ в камеру."
		},
		script: {
			en: "[TABS] This is not studying. This is a museum of guilt.\n[PAPER] One question. 12 minutes. No highlighting as a hobby.\n[TIMER] When it rings you must teach it back in one breath.\n[CAM] If you cannot say it, you do not know it.\n[TEXT] Do this twice. That is a real evening.",
			uk: "[ВКЛАДКИ] Це не навчання. Це музей провини.\n[ПАПІР] Одне питання. 12 хвилин. Без маркування як хобі.\n[ТАЙМЕР] Як задзвонить — поясни на одному подиху.\n[КАМЕРА] Не можеш сказати — не знаєш.\n[ТЕКСТ] Зроби двічі. Ось і вечір."
		},
		caption: {
			en: "Stop collecting notes you will never reread. 12 minutes. One question.",
			uk: "Досить колекціонувати конспекти, які не перечитаєш. 12 хвилин. Одне питання."
		},
		cta: {
			en: "Save and do one round before you scroll further.",
			uk: "Збережи і зроби один раунд, перш ніж скролити далі."
		}
	}, {
		title: {
			en: "I explain compound interest with a sandwich you keep eating",
			uk: "Пояснюю складний відсоток бутербродом, який ти доїдаєш"
		},
		hook: {
			en: "Eat 10% of the sandwich every day. Watch the plate get rude.",
			uk: "Їж 10% бутерброда щодня. Дивись, як тарілка грубіє."
		},
		happens: {
			en: "Stop-motion sandwich shrinking in reverse (it grows). Overlay the same math on a $20 weekly transfer. End on the ugly small start.",
			uk: "Стоп-моушн бутерброда навпаки (він росте). Зверху та сама математика на $20 на тиждень. Фініш — на потворно малому старті."
		},
		script: {
			en: "[PLATE] Day 1 looks pointless. That is the trick.\n[GROW] Interest is just leftover sandwich recruiting more bread.\n[BANK] $20 a week is not a personality. It is a snowball with a job.\n[TEXT] Start ugly. Stay boring. Win quietly.\n[END] Full numbers in the caption.",
			uk: "[ТАРІЛКА] День 1 виглядає безглуздо. В цьому фокус.\n[РІСТ] Відсоток — це залишок бутерброда, що вербує ще хліб.\n[БАНК] $20 на тиждень — не особистість. Це сніжка з роботою.\n[ТЕКСТ] Почни гидко. Будь нудним. Виграй тихо.\n[КІНЕЦЬ] Цифри в описі."
		},
		caption: {
			en: "Compound interest without a suit. $20/week example in slide 2 of your brain.",
			uk: "Складний відсоток без костюма. Приклад $20/тиждень у другому слайді мозку."
		},
		cta: {
			en: "Follow for the next kitchen-table money explainer.",
			uk: "Підпишись — наступне пояснення теж з кухні."
		}
	}],
	other: [{
		title: {
			en: "A format you can steal this week even if your niche is weird",
			uk: "Формат, який можна вкрасти цього тижня, навіть якщо ніша дивна"
		},
		hook: {
			en: "Stop hunting a perfect niche. Hunt a repeatable mechanic.",
			uk: "Досить шукати ідеальну нішу. Шукай механіку, яку можна повторити."
		},
		happens: {
			en: "Show the same 4-beat structure applied to three unrelated topics (plants, legal, street food). Viewer sees the skeleton, not the costume.",
			uk: "Та сама структура з 4 ударів на трьох різних темах (рослини, юриспруденція, стритфуд). Глядач бачить скелет, не костюм."
		},
		script: {
			en: "[BEAT 1] A lie people in your world believe.\n[BEAT 2] Proof in 3 seconds of footage.\n[BEAT 3] The ugly exception.\n[BEAT 4] A challenge they can do before tomorrow.\n[TEXT] That is a series. Not a one-off.",
			uk: "[УДАР 1] Брехня, в яку вірять у твоєму світі.\n[УДАР 2] Доказ за 3 секунди кадру.\n[УДАР 3] Гидкий виняток.\n[УДАР 4] Челендж до завтра.\n[ТЕКСТ] Це серія. Не разове відео."
		},
		caption: {
			en: "Steal the skeleton. Put your weird niche on top. Post three times.",
			uk: "Вкради скелет. Надягни свою дивну нішу. Постіть тричі."
		},
		cta: {
			en: "Comment your niche — I’ll map the 4 beats.",
			uk: "Напиши нішу — розкладу на 4 удари."
		}
	}]
};
var STYLE_NOTE = {
	faceless: {
		en: "Faceless: on-screen text + b-roll + VO. Never show a face.",
		uk: "Без обличчя: текст на екрані + б-ролл + закадровий голос."
	},
	talking: {
		en: "Talking-head: look into lens, jump cuts, handheld closeness.",
		uk: "В кадрі: в об'єктив, скачки монтажу, близька ручна камера."
	},
	gameplay: {
		en: "Gameplay: 80% screen capture, 20% webcam or overlay text.",
		uk: "Геймплей: 80% запис екрана, 20% вебка або текст зверху."
	},
	storytelling: {
		en: "Storytelling: beginning-middle-twist. Hold the secret until second 11.",
		uk: "Історія: зав'язка-середина-твіст. Секрет тримай до 11-ї секунди."
	},
	cinematic: {
		en: "Cinematic: locked-off shots, music swell, color grade, almost no jump cuts.",
		uk: "Кінематограф: статичні плани, саундтрек, колір, майже без скачків."
	}
};
var PLATFORM_LEN = {
	tiktok: {
		en: "12–21s",
		uk: "12–21 с"
	},
	shorts: {
		en: "18–32s",
		uk: "18–32 с"
	},
	reels: {
		en: "15–27s",
		uk: "15–27 с"
	}
};
function defaultTags(input) {
	const p = input.platform === "tiktok" ? ["fyp", "tiktokideas"] : input.platform === "shorts" ? ["shorts", "youtubeshorts"] : ["reels", "reelsideas"];
	return [
		input.niche.replace(/\s+/g, ""),
		p[0],
		p[1],
		"contentcreator",
		"viralhooks",
		input.style,
		"shortform",
		input.language === "uk" ? "українською" : "creator"
	];
}
function mulberry32(a) {
	return function next() {
		a |= 0;
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function pick(rng, list, used) {
	let idx = Math.floor(rng() * list.length);
	for (let i = 0; i < list.length; i += 1) {
		const j = (idx + i) % list.length;
		if (!used.has(j)) {
			used.add(j);
			return list[j];
		}
	}
	return list[idx % list.length];
}
function fallbackIdeas(input) {
	const pool = [...ANGLES[Object.keys(ANGLES).includes(input.niche) ? input.niche : "other"] ?? ANGLES.other, ...ANGLES.other ?? []];
	const rng = mulberry32((input.salt ?? 1) + input.niche.length * 17 + input.platform.length * 31 + input.style.length * 13);
	const used = /* @__PURE__ */ new Set();
	const lang = input.language;
	const ideas = [];
	for (let i = 0; i < 5; i += 1) {
		const angle = pick(rng, pool, used);
		const styleNote = STYLE_NOTE[input.style][lang];
		const titleTwist = i % 2 === 0 ? "" : lang === "uk" ? " — нічний монтаж" : " (night cut)";
		ideas.push({
			title: `${angle.title[lang]}${titleTwist}`.slice(0, 120),
			hook: angle.hook[lang],
			whatHappens: `${angle.happens[lang]} ${styleNote}`,
			script: `${angle.script[lang]}\n\n[${styleNote}]`,
			caption: angle.caption[lang],
			hashtags: defaultTags(input).map((t) => t.startsWith("#") ? t : `#${t}`),
			length: PLATFORM_LEN[input.platform][lang],
			cta: angle.cta[lang],
			platform: input.platform,
			niche: input.niche,
			language: lang,
			style: input.style
		});
	}
	return ideas;
}
var engine_server_exports = /* @__PURE__ */ __exportAll$1({ handleAction: () => handleAction });
function msg(text, extra) {
	return {
		id: randomUUID(),
		role: extra?.role ?? "bot",
		text,
		createdAt: (/* @__PURE__ */ new Date()).toISOString(),
		idea: extra?.idea,
		buttons: extra?.buttons
	};
}
function mainMenu(language) {
	if (language === "uk") return [
		[{
			text: "🎬 Згенерувати ідею",
			action: "generate"
		}],
		[{
			text: "🔥 Тренди",
			action: "trending"
		}, {
			text: "🎯 Ніша",
			action: "choose_niche"
		}],
		[{
			text: "📅 Ідеї дня",
			action: "daily"
		}, {
			text: "💡 Збережені",
			action: "saved"
		}],
		[{
			text: "⚙️ Налаштування",
			action: "settings"
		}]
	];
	return [
		[{
			text: "🎬 Generate Idea",
			action: "generate"
		}],
		[{
			text: "🔥 Trending Ideas",
			action: "trending"
		}, {
			text: "🎯 Choose Niche",
			action: "choose_niche"
		}],
		[{
			text: "📅 Daily Ideas",
			action: "daily"
		}, {
			text: "💡 My Saved Ideas",
			action: "saved"
		}],
		[{
			text: "⚙️ Settings",
			action: "settings"
		}]
	];
}
function welcome(language, name) {
	if (language === "uk") return `Привіт, ${name}. Я Video Ideas Bot — студія коротких відео в кишені.\n\nЗберу 5 ідей під TikTok, YouTube Shorts або Reels: заголовок, гачок на 2–3 с, сценарій, опис і хештеги.\n\nОбери дію:`;
	return `Hey ${name}. I’m Video Ideas Bot — a short-form studio in your pocket.\n\nI’ll write 5 ideas for TikTok, YouTube Shorts or Reels: title, 2–3s hook, script, caption and hashtags.\n\nPick a move:`;
}
function platformButtons() {
	return [PLATFORMS.map((p) => ({
		text: `${PLATFORM_META[p].emoji} ${PLATFORM_META[p].short}`,
		action: `platform:${p}`
	})), [{
		text: "⬅️ Back",
		action: "menu"
	}]];
}
function nicheButtons(language) {
	const rows = [];
	for (let i = 0; i < NICHES.length; i += 3) rows.push(NICHES.slice(i, i + 3).map((n) => ({
		text: `${NICHE_META[n].emoji} ${language === "uk" ? NICHE_META[n].uk : NICHE_META[n].label}`,
		action: `niche:${n}`
	})));
	rows.push([{
		text: "⬅️ Back",
		action: "menu"
	}]);
	return rows;
}
function languageButtons() {
	return [LANGUAGES.map((l) => ({
		text: `${LANG_META[l].flag} ${LANG_META[l].native}`,
		action: `lang:${l}`
	})), [{
		text: "⬅️ Back",
		action: "menu"
	}]];
}
function styleButtons(language) {
	return [
		STYLES.slice(0, 3).map((s) => ({
			text: `${STYLE_META[s].emoji} ${styleLabel(s, language)}`,
			action: `style:${s}`
		})),
		STYLES.slice(3).map((s) => ({
			text: `${STYLE_META[s].emoji} ${styleLabel(s, language)}`,
			action: `style:${s}`
		})),
		[{
			text: "⬅️ Back",
			action: "menu"
		}]
	];
}
function ideaActions(generationId, index, language) {
	const save = language === "uk" ? "❤️ Зберегти" : "❤️ Save";
	const copy = language === "uk" ? "📋 Копіювати" : "📋 Copy";
	return [[{
		text: save,
		action: `save:${generationId}:${index}`
	}, {
		text: copy,
		action: `copy:${generationId}:${index}`
	}]];
}
function afterBatch(generationId, language) {
	const more = language === "uk" ? "🔄 Ще 5 ідей" : "🔄 Generate More";
	const back = language === "uk" ? "⬅️ Меню" : "⬅️ Back";
	return [[{
		text: more,
		action: `more:${generationId}`
	}, {
		text: back,
		action: "menu"
	}]];
}
function limitText(user) {
	if (user.is_premium) return user.language === "uk" ? "Premium: безлімітні генерації." : "Premium: unlimited generations.";
	const left = remainingFor(user);
	return user.language === "uk" ? `Залишилось безкоштовних генерацій сьогодні: ${left}/3.` : `Free generations left today: ${left}/3.`;
}
async function pushAndSave(userId, state, incoming) {
	state.messages = [...state.messages, ...incoming].slice(-80);
	await saveSession(userId, state);
	return incoming;
}
async function handleAction(input) {
	const user = await upsertUser({
		id: input.userId,
		telegramId: input.telegramId,
		username: input.username,
		firstName: input.firstName
	});
	const state = await loadSession(input.userId);
	const language = user.language === "uk" ? "uk" : "en";
	const action = input.action.trim();
	const reply = async (messages, next, copyText) => {
		if (next) Object.assign(state, next);
		const added = await pushAndSave(input.userId, state, messages);
		const fresh = await getUser(input.userId);
		return {
			messages: added,
			user: await toPublic(fresh ?? user),
			copyText
		};
	};
	if (action === "/start" || action === "start" || action === "menu") {
		state.step = "idle";
		state.draft = {};
		return reply([msg(welcome(language, user.first_name || "Creator"), { buttons: mainMenu(language) })], {
			step: "idle",
			draft: {}
		});
	}
	if (state.step === "awaiting_custom_niche" && !action.includes(":")) {
		const niche = action.slice(0, 40);
		await setUserNiche(input.userId, niche);
		state.draft.niche = niche;
		if (!state.draft.platform) return reply([msg(language === "uk" ? `Ніша: ${niche}. Тепер платформа:` : `Niche set: ${niche}. Now pick a platform:`, { buttons: platformButtons() })], {
			step: "gen_platform",
			draft: state.draft
		});
		return reply([msg(language === "uk" ? `Ніша: ${niche}. Мова відео?` : `Niche set: ${niche}. Video language?`, { buttons: languageButtons() })], {
			step: "gen_language",
			draft: state.draft
		});
	}
	if (action === "generate") {
		state.draft = {
			language,
			niche: user.niche ?? void 0
		};
		return reply([msg(language === "uk" ? "Куди знімаємо? TikTok, Shorts чи Reels." : "Where should this live — TikTok, Shorts or Reels?", { buttons: platformButtons() })], {
			step: "gen_platform",
			draft: state.draft
		});
	}
	if (action.startsWith("platform:")) {
		const platform = action.slice(9);
		if (!PLATFORMS.includes(platform)) return reply([msg(language === "uk" ? "Невідома платформа." : "Unknown platform.")]);
		state.draft.platform = platform;
		return reply([msg(language === "uk" ? "Яка ніша?" : "Which niche?", { buttons: nicheButtons(language) })], {
			step: "gen_niche",
			draft: state.draft
		});
	}
	if (action === "choose_niche") return reply([msg(language === "uk" ? "Обери нішу за замовчуванням. Її підставлю в генерації." : "Set a default niche. I’ll pre-fill it on generate.", { buttons: nicheButtons(language) })], { step: "idle" });
	if (action.startsWith("niche:")) {
		const niche = action.slice(6);
		if (niche === "other" && state.step === "gen_niche") return reply([msg(language === "uk" ? "Напиши свою нішу кількома словами." : "Type your niche in a few words.")], {
			step: "awaiting_custom_niche",
			draft: state.draft
		});
		await setUserNiche(input.userId, niche);
		state.draft.niche = niche;
		if (state.step === "gen_niche" || state.draft.platform) return reply([msg(language === "uk" ? "Мова сценарію?" : "Script language?", { buttons: languageButtons() })], {
			step: "gen_language",
			draft: state.draft
		});
		return reply([msg(language === "uk" ? `Нішу збережено: ${nicheLabel(niche, language)}.` : `Niche saved: ${nicheLabel(niche, language)}.`, { buttons: mainMenu(language) })], { step: "idle" });
	}
	if (action.startsWith("lang:")) {
		const nextLang = action.slice(5);
		if (!LANGUAGES.includes(nextLang)) return reply([msg("Unknown language.")]);
		state.draft.language = nextLang;
		await setUserLanguage(input.userId, nextLang);
		if (state.step === "gen_language" || state.draft.platform) return reply([msg(nextLang === "uk" ? "Стиль відео?" : "Video style?", { buttons: styleButtons(nextLang) })], {
			step: "gen_style",
			draft: state.draft
		});
		return reply([msg(nextLang === "uk" ? "Мову оновлено." : "Language updated.", { buttons: mainMenu(nextLang) })], { step: "idle" });
	}
	if (action.startsWith("style:")) {
		const style = action.slice(6);
		if (!STYLES.includes(style)) return reply([msg(language === "uk" ? "Невідомий стиль." : "Unknown style.")]);
		state.draft.style = style;
		return runGeneration(input.userId, user, state, reply);
	}
	if (action.startsWith("more:")) {
		const genId = Number(action.slice(5));
		const prev = Number.isFinite(genId) ? await getGeneration(genId, input.userId) : null;
		if (prev?.[0]) state.draft = {
			platform: prev[0].platform,
			niche: prev[0].niche,
			language: prev[0].language,
			style: prev[0].style
		};
		return runGeneration(input.userId, user, state, reply, prev?.map((i) => i.title));
	}
	if (action.startsWith("save:")) {
		const [, genRaw, idxRaw] = action.split(":");
		const genId = Number(genRaw);
		const idx = Number(idxRaw);
		const idea = (await getGeneration(genId, input.userId))?.[idx];
		if (!idea) return reply([msg(language === "uk" ? "Ідею не знайдено." : "Idea not found.", { buttons: mainMenu(language) })]);
		await saveIdea(input.userId, idea);
		return reply([msg(language === "uk" ? `Збережено: ${idea.title}` : `Saved: ${idea.title}`, { buttons: afterBatch(genId, language) })]);
	}
	if (action.startsWith("copy:")) {
		const [, genRaw, idxRaw] = action.split(":");
		const idea = (await getGeneration(Number(genRaw), input.userId))?.[Number(idxRaw)];
		if (!idea) return reply([msg(language === "uk" ? "Ідею не знайдено." : "Idea not found.")]);
		return reply([msg(language === "uk" ? "Готово до копіювання — текст нижче. Натисни і тримай, щоб скопіювати." : "Copy-ready text below. Long-press to copy."), msg(formatIdeaPlain(idea))], void 0, formatIdeaPlain(idea));
	}
	if (action.startsWith("unsave:")) {
		const id = Number(action.slice(7));
		await deleteSaved(input.userId, id);
		return reply([msg(language === "uk" ? "Видалено зі збережених." : "Removed from saved.", { buttons: mainMenu(language) })]);
	}
	if (action === "trending" || action === "daily") {
		const pack = await cachedPack(action, language);
		const messages = [msg(action === "trending" ? language === "uk" ? "🔥 Тренди сьогодні — 5 ідей, які зараз заходять." : "🔥 Today’s trending pack — five ideas with heat." : language === "uk" ? "📅 Ідеї дня. Одна порція на всіх, щоб стрічка не повторювалась." : "📅 Daily ideas. One pack for everyone, so the feed stays fresh.")];
		pack.forEach((idea, i) => {
			messages.push(msg(stripHtml(formatIdeaHtml(idea, i + 1)), { idea }));
		});
		messages.push(msg(language === "uk" ? "Далі?" : "What next?", { buttons: mainMenu(language) }));
		return reply(messages, { step: "idle" });
	}
	if (action === "saved") {
		const saved = await listSaved(input.userId);
		if (!saved.length) return reply([msg(language === "uk" ? "Поки порожньо. Згенеруй ідею і натисни ❤️." : "Nothing saved yet. Generate an idea and tap ❤️.", { buttons: mainMenu(language) })]);
		const messages = [msg(language === "uk" ? `Збережено: ${saved.length}` : `Saved ideas: ${saved.length}`)];
		for (const row of saved.slice(0, 8)) messages.push(msg(stripHtml(formatIdeaHtml(row.idea, 1)), {
			idea: row.idea,
			buttons: [[{
				text: language === "uk" ? "🗑️ Видалити" : "🗑️ Remove",
				action: `unsave:${row.id}`
			}]]
		}));
		messages.push(msg(language === "uk" ? "Меню" : "Menu", { buttons: mainMenu(language) }));
		return reply(messages);
	}
	if (action === "settings") {
		const niche = user.niche ? nicheLabel(user.niche, language) : language === "uk" ? "не обрана" : "not set";
		const premiumLine = user.is_premium ? language === "uk" ? "Статус: Premium · безліміт" : "Status: Premium · unlimited" : language === "uk" ? "Статус: Free · 3 генерації / день" : "Status: Free · 3 generations / day";
		const buttons = [[{
			text: `${LANG_META.en.flag} English`,
			action: "setlang:en"
		}, {
			text: `${LANG_META.uk.flag} Українська`,
			action: "setlang:uk"
		}], [{
			text: language === "uk" ? "🎯 Змінити нішу" : "🎯 Change niche",
			action: "choose_niche"
		}]];
		if (isPreview() && !user.is_premium) buttons.push([{
			text: language === "uk" ? "👑 Увімкнути Premium (демо)" : "👑 Unlock Premium (demo)",
			action: "premium_demo"
		}]);
		buttons.push([{
			text: language === "uk" ? "⬅️ Меню" : "⬅️ Back",
			action: "menu"
		}]);
		return reply([msg([
			language === "uk" ? "⚙️ Налаштування" : "⚙️ Settings",
			"",
			premiumLine,
			limitText(user),
			language === "uk" ? `Ніша: ${niche}` : `Niche: ${niche}`,
			language === "uk" ? `Мова: ${LANG_META[language].native}` : `Language: ${LANG_META[language].native}`
		].join("\n"), { buttons })]);
	}
	if (action.startsWith("setlang:")) {
		const nextLang = action.slice(8);
		if (!LANGUAGES.includes(nextLang)) return reply([msg("Unknown language.")]);
		await setUserLanguage(input.userId, nextLang);
		return reply([msg(nextLang === "uk" ? "Мову змінено на українську." : "Language set to English.", { buttons: mainMenu(nextLang) })]);
	}
	if (action === "premium_demo" && isPreview()) {
		await setPremium(input.userId, true);
		return reply([msg(language === "uk" ? "Premium увімкнено для цього прев’ю. Генерації без ліміту." : "Premium is on for this preview. Generate without a daily cap.", { buttons: mainMenu(language) })]);
	}
	if (action === "help" || action === "/help") return reply([msg(language === "uk" ? "Команди: /start — меню. Генеруй ідеї, зберігай, дивись тренди. 3 безкоштовні генерації на день." : "Commands: /start opens the menu. Generate, save, browse trends. 3 free generations a day.", { buttons: mainMenu(language) })]);
	return reply([msg(language === "uk" ? "Не зрозумів. Обери кнопку в меню." : "Didn’t catch that. Use the menu.", { buttons: mainMenu(language) })]);
}
function stripHtml(html) {
	return html.replaceAll("<b>", "").replaceAll("</b>", "").replaceAll("<br>", "\n").replaceAll("&", "&").replaceAll("<", "<").replaceAll(">", ">");
}
async function runGeneration(userId, user, state, reply, avoidTitles) {
	const language = state.draft.language ?? (user.language === "uk" ? "uk" : "en");
	const platform = state.draft.platform;
	const niche = state.draft.niche ?? user.niche ?? "lifestyle";
	const style = state.draft.style;
	if (!platform || !style) return reply([msg(language === "uk" ? "Спочатку обери платформу і стиль." : "Pick a platform and style first.", { buttons: mainMenu(language) })], { step: "idle" });
	if (!await consumeGeneration(userId)) return reply([msg(language === "uk" ? "Ліміт на сьогодні вичерпано (3/3). Premium знімає ліміт — або повернись завтра." : "That’s the daily cap (3/3). Premium unlocks unlimited ideas — or come back tomorrow.", { buttons: mainMenu(language) })], { step: "idle" });
	const ideas = await generateIdeas({
		platform,
		niche,
		language,
		style,
		avoidTitles
	});
	const generationId = await persistGeneration({
		userId,
		platform,
		niche,
		language,
		style,
		ideas
	});
	state.lastGenerationId = generationId;
	state.step = "idle";
	const messages = [msg(language === "uk" ? `5 ідей · ${PLATFORM_META[platform].label} · ${nicheLabel(niche, language)} · ${styleLabel(style, language)}\n${limitText(await getUser(userId) ?? user)}` : `5 ideas · ${PLATFORM_META[platform].label} · ${nicheLabel(niche, language)} · ${styleLabel(style, language)}\n${limitText(await getUser(userId) ?? user)}`)];
	ideas.forEach((idea, i) => {
		messages.push(msg(stripHtml(formatIdeaHtml(idea, i + 1)), {
			idea,
			buttons: ideaActions(generationId, i, language)
		}));
	});
	messages.push(msg(language === "uk" ? "Ще за цим брифом?" : "Want another batch with this brief?", { buttons: afterBatch(generationId, language) }));
	return reply(messages, {
		lastGenerationId: generationId,
		step: "idle",
		draft: state.draft
	});
}
//#endregion
export { handleAction as n, engine_server_x6ynx2FI_exports as t };
