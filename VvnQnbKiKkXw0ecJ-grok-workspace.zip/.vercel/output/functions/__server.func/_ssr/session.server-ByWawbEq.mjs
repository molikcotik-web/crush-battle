import { createHmac, randomUUID, timingSafeEqual } from "node:crypto";
//#region node_modules/.nitro/vite/services/ssr/assets/session.server-ByWawbEq.js
function env(key) {
	return process.env[key]?.trim() || void 0;
}
var TOKEN_TTL_SEC = 31536e3;
function secret() {
	return env("SESSION_SECRET") ?? env("TELEGRAM_BOT_TOKEN") ?? "vib-preview-session-key";
}
function sign(payload) {
	return createHmac("sha256", secret()).update(payload).digest("base64url");
}
function issueSessionToken(userId) {
	const exp = Math.floor(Date.now() / 1e3) + TOKEN_TTL_SEC;
	const payload = Buffer.from(JSON.stringify({
		id: userId,
		exp
	})).toString("base64url");
	return `${payload}.${sign(payload)}`;
}
function verifySessionToken(token) {
	if (!token) return null;
	const [payload, sig] = token.split(".");
	if (!payload || !sig) return null;
	const expected = sign(payload);
	const a = Buffer.from(sig);
	const b = Buffer.from(expected);
	if (a.length !== b.length) return null;
	if (!timingSafeEqual(a, b)) return null;
	try {
		const data = JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
		if (typeof data.id !== "string" || typeof data.exp !== "number") return null;
		if (data.exp < Math.floor(Date.now() / 1e3)) return null;
		if (!data.id.startsWith("web:") && !/^\d+$/.test(data.id) && !data.id.startsWith("tg:")) return null;
		return data.id;
	} catch {
		return null;
	}
}
function newWebUserId() {
	return `web:${randomUUID()}`;
}
function telegramUserId(telegramId) {
	return `tg:${telegramId}`;
}
function isPreview() {
	return !env("GROK_PROJECT_ID");
}
function adminIds() {
	return (env("TELEGRAM_ADMIN_IDS") ?? "").split(",").map((s) => s.trim()).filter(Boolean);
}
function webhookSecret() {
	return env("TELEGRAM_WEBHOOK_SECRET");
}
function botToken() {
	return env("TELEGRAM_BOT_TOKEN");
}
function adminSecret() {
	return env("ADMIN_SECRET");
}
//#endregion
export { adminIds, adminSecret, botToken, isPreview, issueSessionToken, newWebUserId, telegramUserId, verifySessionToken, webhookSecret };
