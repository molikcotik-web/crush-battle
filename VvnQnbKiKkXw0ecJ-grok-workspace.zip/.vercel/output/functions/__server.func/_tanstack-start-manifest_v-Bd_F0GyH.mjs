//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Bd_F0GyH.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/bot",
			"/api/health",
			"/api/telegram/webhook"
		],
		preloads: ["/assets/index-MLmAgeh_.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-MLmAgeh_.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CsdUg-gj.js",
			"/assets/utils-r2m6WffF.js",
			"/assets/button-DKwCEyjb.js",
			"/assets/chat-C4jB3GbS.js"
		]
	},
	"/admin": {
		filePath: "/workspace/src/routes/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-DCMGGDRq.js",
			"/assets/utils-r2m6WffF.js",
			"/assets/arrow-left-Dl01UgpC.js",
			"/assets/button-DKwCEyjb.js"
		]
	},
	"/bot": {
		filePath: "/workspace/src/routes/bot.tsx",
		children: void 0,
		preloads: [
			"/assets/bot-ClNI_JeU.js",
			"/assets/arrow-left-Dl01UgpC.js",
			"/assets/chat-C4jB3GbS.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
